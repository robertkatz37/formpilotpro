<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ── Save / update a form (admin only) ─────────────────────────────────────
add_action( 'wp_ajax_ssb_save_form', 'ssb_ajax_save_form' );
function ssb_ajax_save_form() {
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg' => 'Unauthorized']);
    if ( ! ssb_is_paid() && empty($_POST['form_id']) && ssb_free_form_count() >= ssb_free_limits()['forms'] ) wp_send_json_error(['msg'=>ssb_free_limit_notice('forms'),'upgrade'=>true],403);
    check_ajax_referer( 'ssb_forms_nonce', 'nonce' );

    global $wpdb;
    $table = $wpdb->prefix . 'ssb_forms';

    $id          = intval( $_POST['form_id'] ?? 0 );
    $name        = sanitize_text_field( $_POST['form_name'] ?? '' );
    $description = sanitize_textarea_field( $_POST['description'] ?? '' );
    $fields_raw  = wp_unslash( $_POST['fields'] ?? '[]' );
    $settings_raw = wp_unslash( $_POST['settings'] ?? '{}' );

    if ( ! $name ) wp_send_json_error(['msg' => 'Form name is required']);

    // Validate JSON
    $fields   = json_decode( $fields_raw, true );
    $settings = json_decode( $settings_raw, true );
    if ( ! is_array($fields) )   $fields   = [];
    if ( ! is_array($settings) ) $settings = [];

    // Sanitize each field definition
    $clean_fields = [];
    foreach ( $fields as $f ) {
        $clean_fields[] = [
            'id'          => sanitize_key( $f['id'] ?? uniqid('f') ),
            'type'        => sanitize_key( $f['type'] ?? 'text' ),
            'label'       => sanitize_text_field( $f['label'] ?? '' ),
            'placeholder' => sanitize_text_field( $f['placeholder'] ?? '' ),
            'required'    => ! empty( $f['required'] ),
            'options'     => isset($f['options']) ? array_map('sanitize_text_field', (array)$f['options']) : [],
            'width'       => in_array($f['width'] ?? 'full', ['full','half']) ? $f['width'] : 'full',
            'help_text'   => sanitize_text_field( $f['help_text'] ?? '' ),
            'style'       => ssb_sanitize_field_style( isset($f['style']) && is_array($f['style']) ? $f['style'] : [] ),
            'style_customized' => !empty($f['style_customized']),
        ];
    }

    // Free tier: premium integrations are disabled unless a valid paid entitlement exists.
    $has_stripe = !empty($settings['integrations']['stripe']['enabled']);
    $has_calendar = !empty($settings['integrations']['google_calendar']['enabled']);
    if (!ssb_is_paid()) {
        if ($has_stripe) wp_send_json_error(['msg'=>ssb_feature_locked_message('stripe'),'upgrade'=>true],403);
        if ($has_calendar) wp_send_json_error(['msg'=>ssb_feature_locked_message('calendar'),'upgrade'=>true],403);
        if (!empty($settings['style']['custom_css'])) wp_send_json_error(['msg'=>ssb_feature_locked_message('advanced_styling'),'upgrade'=>true],403);
    }

    // Sanitize settings
    $clean_settings = [
        'notify_email'  => implode( ',', array_filter( array_map( 'sanitize_email', explode( ',', $settings['notify_email'] ?? get_option('admin_email') ) ) ) ),
        'success_msg'   => sanitize_textarea_field( $settings['success_msg'] ?? 'Thank you! Your message has been sent.' ),
        'submit_label'  => sanitize_text_field( $settings['submit_label'] ?? 'Submit' ),
        'display_title' => sanitize_text_field( $settings['display_title'] ?? $name ),
        'show_title' => array_key_exists('show_title', $settings) ? !empty($settings['show_title']) : true,
        'show_description' => array_key_exists('show_description', $settings) ? !empty($settings['show_description']) : true,
        'show_labels' => array_key_exists('show_labels', $settings) ? !empty($settings['show_labels']) : true,
        'send_copy'     => ! empty( $settings['send_copy'] ),
        'email_subject' => sanitize_text_field( $settings['email_subject'] ?? '' ),
        'redirect_url'  => esc_url_raw( $settings['redirect_url'] ?? '' ),
        'primary_color' => sanitize_hex_color( $settings['primary_color'] ?? '' ),
        'btn_radius'    => intval( $settings['btn_radius'] ?? -1 ),
        'integrations'  => [
            'stripe' => [
                'enabled' => !empty($settings['integrations']['stripe']['enabled']),
                'amount' => max(0, floatval($settings['integrations']['stripe']['amount'] ?? 0)),
                'currency' => sanitize_text_field($settings['integrations']['stripe']['currency'] ?? 'USD'),
                'description' => sanitize_text_field($settings['integrations']['stripe']['description'] ?? ''),
            ],
            'google_calendar' => [
                'enabled' => !empty($settings['integrations']['google_calendar']['enabled']),
                'calendar_id' => sanitize_text_field($settings['integrations']['google_calendar']['calendar_id'] ?? 'primary'),
                'event_label' => sanitize_text_field($settings['integrations']['google_calendar']['event_label'] ?? ''),
                'brand_name' => sanitize_text_field($settings['integrations']['google_calendar']['brand_name'] ?? ''),
            ],
        ],
        'style' => ssb_sanitize_form_style( isset($settings['style']) && is_array($settings['style']) ? $settings['style'] : [] ),
    ];

    if (!ssb_is_paid()) {
        // Free tier keeps the builder usable but uses the standard FormPilot presentation.
        $clean_settings['primary_color'] = '#6366f1';
        $clean_settings['btn_radius'] = 10;
        $clean_settings['style'] = [];
    }

    $slug = ssb_unique_slug( $name, $id );

    $data = [
        'form_name'   => $name,
        'form_slug'   => $slug,
        'description' => $description,
        'fields'      => wp_json_encode( $clean_fields ),
        'settings'    => wp_json_encode( $clean_settings ),
    ];

    if ( $id ) {
        $wpdb->update( $table, $data, ['id' => $id] );
        wp_send_json_success(['msg' => 'Form updated', 'form_id' => $id, 'slug' => $slug]);
    } else {
        $data['status'] = 'active';
        $wpdb->insert( $table, $data );
        $new_id = $wpdb->insert_id;
        wp_send_json_success(['msg' => 'Form created', 'form_id' => $new_id, 'slug' => $slug]);
    }
}


// ── Per-form style sanitizer ───────────────────────────────────────────────
function ssb_sanitize_form_style($style) {
    $hex = function($v,$fallback='') {
        $v = sanitize_hex_color($v);
        return $v ?: $fallback;
    };
    return [
        'form_bg' => $hex($style['form_bg'] ?? '', '#ffffff'),
        'form_bg_transparent' => !empty($style['form_bg_transparent']),
        'form_border_enabled' => array_key_exists('form_border_enabled',$style) ? !empty($style['form_border_enabled']) : true,
        'form_border' => $hex($style['form_border'] ?? '', '#edf0f3'),
        'form_radius' => max(0, min(60, intval($style['form_radius'] ?? 24))),
        'form_padding' => max(0, min(100, intval($style['form_padding'] ?? 40))),
        'field_gap' => max(0, min(60, intval($style['field_gap'] ?? 18))),
        'label_color' => $hex($style['label_color'] ?? '', '#6b7280'),
        'label_size' => max(9, min(24, intval($style['label_size'] ?? 12))),
        'input_bg' => $hex($style['input_bg'] ?? '', '#f9fafb'),
        'input_text' => $hex($style['input_text'] ?? '', '#111827'),
        'input_border' => $hex($style['input_border'] ?? '', '#e5e7eb'),
        'input_focus_border' => $hex($style['input_focus_border'] ?? '', '#667eea'),
        'input_focus_ring' => $hex($style['input_focus_ring'] ?? '', '#dbeafe'),
        'input_error_border' => $hex($style['input_error_border'] ?? '', '#dc2626'),
        'input_error_bg' => $hex($style['input_error_bg'] ?? '', '#fef2f2'),
        'input_placeholder' => $hex($style['input_placeholder'] ?? '', '#94a3b8'),
        'input_border_width' => max(0, min(6, intval($style['input_border_width'] ?? 1))),
        'input_radius' => max(0, min(60, intval($style['input_radius'] ?? 12))),
        'input_padding' => max(4, min(40, intval($style['input_padding'] ?? 14))),
        'input_font_size' => max(10, min(30, intval($style['input_font_size'] ?? 15))),
        'button_bg' => $hex($style['button_bg'] ?? '', '#667eea'),
        'button_text' => $hex($style['button_text'] ?? '', '#ffffff'),
        'button_hover_bg' => $hex($style['button_hover_bg'] ?? '', '#4f46e5'),
        'button_radius' => max(0, min(60, intval($style['button_radius'] ?? 999))),
        'button_padding_y' => max(4, min(40, intval($style['button_padding_y'] ?? 15))),
        'button_padding_x' => max(4, min(80, intval($style['button_padding_x'] ?? 34))),
        'button_font_size' => max(10, min(30, intval($style['button_font_size'] ?? 15))),
        'button_full_width' => !empty($style['button_full_width']),
    ];
}

// Field styles are opt-in. Empty/unchanged fields inherit the form-level styling.
function ssb_sanitize_field_style($style) {
    $out = [];
    $hex_keys = ['bg','text','border'];
    foreach ($hex_keys as $key) {
        if (array_key_exists($key,$style)) {
            $v = sanitize_hex_color($style[$key]);
            if ($v) $out[$key] = $v;
        }
    }
    foreach (['border_width'=>[0,6],'radius'=>[0,60],'font_size'=>[10,30],'padding'=>[4,40]] as $key=>$range) {
        if (array_key_exists($key,$style)) $out[$key] = max($range[0],min($range[1],intval($style[$key])));
    }
    return $out;
}

// ── Import dropdown options from CSV ────────────────────────────────────────
add_action('wp_ajax_ssb_import_select_csv', 'ssb_ajax_import_select_csv');
function ssb_ajax_import_select_csv() {
    if ( function_exists('ssb_license_can') && ! ssb_license_can('builder') ) wp_send_json_error(['msg'=>'A valid FormPilot Pro license is required.'], 403);
    check_ajax_referer('ssb_forms_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['msg'=>'Unauthorized']);
    if (empty($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['msg'=>'Please choose a valid CSV file.']);
    }
    $file = $_FILES['csv_file'];
    if (($file['size'] ?? 0) > 5 * 1024 * 1024) wp_send_json_error(['msg'=>'CSV file must be 5 MB or smaller.']);
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'csv') wp_send_json_error(['msg'=>'Only .csv files are supported.']);

    $fh = fopen($file['tmp_name'], 'r');
    if (!$fh) wp_send_json_error(['msg'=>'Could not read the CSV file.']);
    $options = [];
    $row = 0;
    while (($data = fgetcsv($fh)) !== false) {
        $row++;
        $cell = trim(sanitize_text_field($data[0] ?? ''));
        // Accept a simple one-column CSV. Ignore common header names.
        if ($row === 1 && in_array(strtolower($cell), ['option','options','value','values','label','labels','name','names'], true)) continue;
        if ($cell !== '') $options[] = $cell;
    }
    fclose($fh);
    $options = array_values(array_unique($options));
    if (!$options) wp_send_json_error(['msg'=>'No values were found in the CSV.']);
    wp_send_json_success(['options'=>$options, 'count'=>count($options)]);
}

// ── Delete a form ──────────────────────────────────────────────────────────
add_action( 'wp_ajax_ssb_delete_form', 'ssb_ajax_delete_form' );
function ssb_ajax_delete_form() {
    check_ajax_referer( 'ssb_forms_nonce', 'nonce' );
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg' => 'Unauthorized']);

    global $wpdb;
    $id = intval( $_POST['form_id'] ?? 0 );
    if ( ! $id ) wp_send_json_error(['msg' => 'Invalid ID']);

    $wpdb->delete( $wpdb->prefix . 'ssb_forms',        ['id'      => $id] );
    $wpdb->delete( $wpdb->prefix . 'ssb_form_entries', ['form_id' => $id] );

    wp_send_json_success(['msg' => 'Form deleted']);
}

// ── Front-end form submission ──────────────────────────────────────────────
add_action( 'wp_ajax_ssb_submit_form',        'ssb_ajax_submit_form' );
add_action( 'wp_ajax_nopriv_ssb_submit_form', 'ssb_ajax_submit_form' );
function ssb_ajax_submit_form() {
    if (!ssb_is_paid() && ssb_free_entries_this_month() >= ssb_free_limits()['entries_month']) wp_send_json_error(['msg'=>ssb_free_limit_notice('entries'),'upgrade'=>true],403);
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg' => 'Unauthorized']);
    if ( ! ssb_is_paid() && empty($_POST['form_id']) && ssb_free_form_count() >= ssb_free_limits()['forms'] ) wp_send_json_error(['msg'=>ssb_free_limit_notice('forms'),'upgrade'=>true],403);
    check_ajax_referer( 'ssb_form_submit', 'nonce' );

    global $wpdb;
    $form_id = intval( $_POST['form_id'] ?? 0 );
    $form    = ssb_get_form( $form_id );

    if ( ! $form || $form->status !== 'active' ) {
        wp_send_json_error(['msg' => 'Form not found']);
    }

    $entry_data        = [];
    $errors            = [];
    $field_errors      = [];
    $client_tz_id      = sanitize_text_field( $_POST['client_timezone'] ?? '' );
    $client_tz_display = sanitize_text_field( $_POST['client_timezone_display'] ?? $client_tz_id );

    // ── Collect field values ────────────────────────────────────────────────
    $selected_timeslot = '';   // stores a chosen time slot value if present
    $date_field_value  = '';
    $canonical = null;   // date field value for slot conflict check

    foreach ( $form->fields as $field ) {
        $key   = 'field_' . $field['id'];
        $raw   = $_POST[ $key ] ?? '';

        // Handle checkbox arrays
        if ( $field['type'] === 'checkbox' && is_array($raw) ) {
            $value = implode(', ', array_map('sanitize_text_field', $raw));
        } else {
            $value = sanitize_text_field( $raw );
        }

        if ( $field['required'] && trim($value) === '' ) {
            $message = $field['label'] . ' is required.';
            $errors[] = $message;
            $field_errors[$key] = $message;
        }

        if ( $field['type'] === 'email' && $value && ! is_email($value) ) {
            $message = $field['label'] . ' must be a valid email address.';
            $errors[] = $message;
            $field_errors[$key] = $message;
        }

        // Track timeslot and date fields for conflict check
        if ( in_array( $field['type'], ['timeslot','time'], true ) && $value ) {
            $selected_timeslot = $value;
        }
        if ( $field['type'] === 'date' && $value ) {
            $date_field_value = $value;
        }

        $entry_data[ $field['label'] ] = $value;
    }

    if ( $errors ) {
        wp_send_json_error(['msg' => implode(' ', $errors), 'errors' => $field_errors]);
    }

    // Verify a per-form Stripe payment before saving the entry.
    $integrations = $form->settings['integrations'] ?? [];
    $stripe_cfg = $integrations['stripe'] ?? [];
    $payment_intent_id = sanitize_text_field($_POST['payment_intent_id'] ?? '');
    if (!empty($stripe_cfg['enabled']) && floatval($stripe_cfg['amount'] ?? 0) > 0) {
        if (!$payment_intent_id) wp_send_json_error(['msg'=>'Payment is required before submitting this form.']);
        $secret = get_option('ssb_stripe_secret_key','');
        $check = $secret ? wp_remote_get('https://api.stripe.com/v1/payment_intents/'.rawurlencode($payment_intent_id), [
            'headers'=>['Authorization'=>'Bearer '.$secret], 'timeout'=>20
        ]) : false;
        $pi = ($check && !is_wp_error($check)) ? json_decode(wp_remote_retrieve_body($check),true) : [];
        $expected_amount = (int)round(floatval($stripe_cfg['amount']) * 100);
        if (empty($pi['id']) || !in_array(($pi['status'] ?? ''), ['succeeded','requires_capture'], true) || intval($pi['amount'] ?? 0) !== $expected_amount) {
            wp_send_json_error(['msg'=>'Payment could not be verified. Please try again.']);
        }
    }

    // ── Timeslot conflict check ─────────────────────────────────────────────
    // If the form has a timeslot field and a date, verify the slot isn't already booked
    if ( $selected_timeslot && $date_field_value ) {
        $tz_id    = $client_tz_id ?: 'America/New_York';
        $canonical = ssb_parse_to_canonical( $date_field_value, $selected_timeslot, $tz_id );
        if ( $canonical ) {
            $bookings_table = $wpdb->prefix . 'schedule_bookings';
            $table_exists   = $wpdb->get_var( "SHOW TABLES LIKE '$bookings_table'" );
            if ( $table_exists ) {
                $conflict = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM $bookings_table WHERE canonical_start = %s AND status = 'confirmed' LIMIT 1",
                    $canonical['start']->format('Y-m-d H:i:s')
                ));
                if ( $conflict ) {
                    wp_send_json_error(['msg' => 'Sorry, the selected time slot (' . esc_html($selected_timeslot) . ') is already booked. Please choose a different time.', 'slot_taken' => true]);
                }
            }
        }
    }

    $settings = $form->settings;
    // ── Build timezone info for email ───────────────────────────────────────
    $tz_info = '';
    if ( $client_tz_id ) {
        $eastern_tz  = new DateTimeZone('America/New_York');
        $eastern_now = new DateTime('now', $eastern_tz);
        $eastern_abbr = $eastern_now->format('T'); // EST or EDT

        $client_label = $client_tz_display ?: $client_tz_id;

        // If there's a timeslot + date, convert the specific time to Eastern
        if ( $selected_timeslot && $date_field_value ) {
            try {
                $dt_client = new DateTime( $date_field_value . ' ' . $selected_timeslot, new DateTimeZone($client_tz_id) );
                $dt_eastern = clone $dt_client;
                $dt_eastern->setTimezone( $eastern_tz );
                $eastern_time_str = $dt_eastern->format('g:i A') . ' ' . $eastern_abbr . ' (' . $dt_eastern->format('D, M j, Y') . ')';
                $client_time_str  = $dt_client->format('g:i A') . ' — ' . $client_label;
                $tz_info = $client_time_str . ' / ' . $eastern_time_str;
            } catch ( Exception $e ) {
                $tz_info = $client_label;
            }
        } else {
            $tz_info = $client_label;
        }
    }

    // Save entry (append integration metadata to entry_data for record keeping)
    $entry_data_to_save = $entry_data;
    if ( $tz_info ) {
        $entry_data_to_save['__timezone__'] = $tz_info;
    }
    if ( $client_tz_id ) {
        $entry_data_to_save['__timezone_id__'] = sanitize_text_field($client_tz_id);
    }
    if ( $payment_intent_id ) $entry_data_to_save['__payment_intent__'] = $payment_intent_id;

    $wpdb->insert( $wpdb->prefix . 'ssb_form_entries', [
        'form_id'    => $form_id,
        'entry_data' => wp_json_encode( $entry_data_to_save ),
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500 ),
        'status'     => 'unread',
    ]);
    $saved_entry_id = (int) $wpdb->insert_id;

    // Per-form Google Calendar integration. Global OAuth credentials are reused,
    // while calendar ID, label and brand can be selected independently per form.
    $integrations = $settings['integrations'] ?? [];
    if ( ! empty($integrations['google_calendar']['enabled']) && $selected_timeslot && $date_field_value ) {
        $email = '';
        $phone = '';
        $first = '';
        $last = '';
        foreach ($form->fields as $field) {
            $v = $entry_data[$field['label']] ?? '';
            if ($field['type'] === 'email' && !$email) $email = $v;
            if ($field['type'] === 'phone' && !$phone) $phone = $v;
            if (!$first && stripos($field['label'],'first') !== false) $first = $v;
            if (!$last && stripos($field['label'],'last') !== false) $last = $v;
        }
        if (!$first && !$last) {
            foreach ($form->fields as $field) {
                if (stripos($field['label'],'name') !== false && !empty($entry_data[$field['label']])) {
                    $parts = preg_split('/\s+/', trim($entry_data[$field['label']]), 2);
                    $first = $parts[0] ?? '';
                    $last = $parts[1] ?? '';
                    break;
                }
            }
        }
        if ($email && $canonical) {
            $end = clone $canonical['start'];
            $end->modify('+30 minutes');
            $calendar_booking = [
                'first_name' => $first ?: 'Guest',
                'last_name' => $last,
                'email' => $email,
                'phone' => $phone,
                'practice_type' => '',
                'booking_date' => $date_field_value,
                'booking_time' => $selected_timeslot,
                'timezone' => $client_tz_id ?: 'UTC',
                'timezone_display' => $client_tz_display ?: ($client_tz_id ?: 'UTC'),
                'canonical_start_iso' => $canonical['start']->format(DateTime::ATOM),
                'canonical_end_iso' => $end->format(DateTime::ATOM),
            ];
            $google_result = ssb_create_google_calendar_event($calendar_booking, $integrations['google_calendar']);
            if ( $saved_entry_id && ! is_wp_error($google_result) ) {
                $entry_meta = $entry_data_to_save;
                if ( ! empty($google_result['event_id']) ) $entry_meta['__google_event_id__'] = sanitize_text_field($google_result['event_id']);
                if ( ! empty($google_result['meet_link']) ) $entry_meta['__meeting_url__'] = esc_url_raw($google_result['meet_link']);
                if ( ! empty($google_result['html_link']) ) $entry_meta['__calendar_url__'] = esc_url_raw($google_result['html_link']);
                $wpdb->update($wpdb->prefix . 'ssb_form_entries', ['entry_data'=>wp_json_encode($entry_meta)], ['id'=>$saved_entry_id]);
            }
        }
    }

    // Send notification email (pass timezone info)
    ssb_send_form_notification( $form, $entry_data, $tz_info );

    // Send copy to submitter if enabled

    if ( ! empty($settings['send_copy']) ) {
        $submitter_email = '';
        foreach ( $form->fields as $field ) {
            if ( $field['type'] === 'email' ) {
                $submitter_email = $entry_data[ $field['label'] ] ?? '';
                break;
            }
        }
        if ( $submitter_email ) {
            ssb_send_form_copy( $form, $entry_data, $submitter_email );
        }
    }

    $redirect = $settings['redirect_url'] ?? '';
    wp_send_json_success([
        'msg'         => $settings['success_msg'] ?? 'Thank you! Your message has been sent.',
        'redirect'    => $redirect,
    ]);
}

// ── Mark entry read / delete entry ────────────────────────────────────────
add_action( 'wp_ajax_ssb_update_entry', 'ssb_ajax_update_entry' );
function ssb_ajax_update_entry() {
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg' => 'Unauthorized']);
    if ( ! ssb_is_paid() && empty($_POST['form_id']) && ssb_free_form_count() >= ssb_free_limits()['forms'] ) wp_send_json_error(['msg'=>ssb_free_limit_notice('forms'),'upgrade'=>true],403);
    check_ajax_referer( 'ssb_forms_nonce', 'nonce' );
    if ( ! current_user_can('manage_options') ) wp_send_json_error();

    global $wpdb;
    $entry_id = intval( $_POST['entry_id'] ?? 0 );
    $action   = sanitize_key( $_POST['entry_action'] ?? '' );

    if ( $action === 'delete' ) {
        $wpdb->delete( $wpdb->prefix . 'ssb_form_entries', ['id' => $entry_id] );
        wp_send_json_success(['msg' => 'Entry deleted']);
    } elseif ( $action === 'read' ) {
        $wpdb->update( $wpdb->prefix . 'ssb_form_entries', ['status' => 'read'], ['id' => $entry_id] );
        wp_send_json_success(['msg' => 'Marked as read']);
    }
    wp_send_json_error();
}

// ── Email notifications ────────────────────────────────────────────────────
function ssb_send_form_notification( $form, $entry_data, $tz_info = '' ) {
    $settings = $form->settings;
    $raw_emails = $settings['notify_email'] ?? get_option('admin_email');

// Support comma, semicolon, or newline separated emails
$emails = preg_split('/[,;\r\n]+/', $raw_emails);

$emails = array_map('trim', $emails);

$emails = array_filter($emails, function($email) {
    return is_email($email);
});

if (empty($emails)) {
    $emails = [get_option('admin_email')];
}
    $subject  = ! empty($settings['email_subject']) ? $settings['email_subject'] : $form->form_name;
    $headers  = ssb_get_email_headers();

    $rows = '';
    foreach ( $entry_data as $label => $value ) {
        if ( substr($label, 0, 2) === '__' ) continue;
        $rows .= '<tr>
            <td style="padding:10px 14px;font-weight:700;background:#f9fafb;border:1px solid #e5e7eb;width:35%;font-family:Plus Jakarta Sans,Arial,sans-serif;">' . esc_html($label) . '</td>
            <td style="padding:10px 14px;border:1px solid #e5e7eb;font-family:Plus Jakarta Sans,Arial,sans-serif;">' . nl2br(esc_html($value)) . '</td>
        </tr>';
    }

    $tz_row = '';
    if ( $tz_info ) {
        $eastern_abbr = 'ET';
        try {
            $now_et = new DateTime('now', new DateTimeZone('America/New_York'));
            $eastern_abbr = $now_et->format('T');
        } catch (Exception $e) {}
        $tz_row = '<tr><td colspan="2" style="padding:12px 16px;background:#eff6ff;border:1px solid #bfdbfe;">'
            . '<span style="font-family:Plus Jakarta Sans,Arial,sans-serif;font-size:13px;color:#1e40af;">'
            . '&#127758; <strong>Client Timezone &amp; Slot:</strong> ' . esc_html($tz_info)
            . ' &nbsp;&middot;&nbsp; <em>You manage in Eastern Time (' . esc_html($eastern_abbr) . ')</em>'
            . '</span></td></tr>';
    }

    $message = '<!DOCTYPE html><html><body style="font-family:Plus Jakarta Sans,Arial,sans-serif;color:#333;margin:0;padding:0;">'
        . '<div style="max-width:600px;margin:0 auto;padding:20px;">'
        . '<div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:24px;border-radius:10px 10px 0 0;color:#fff;">'
        . '<h2 style="margin:0;font-family:Plus Jakarta Sans,Arial,sans-serif;">&#128236; ' . esc_html($subject) . '</h2>'
        . '<p style="margin:8px 0 0;opacity:0.85;font-family:Plus Jakarta Sans,Arial,sans-serif;">Form: <strong>' . esc_html($form->form_name) . '</strong></p>'
        . '</div>'
        . '<div style="background:#fff;padding:24px;border:1px solid #e5e7eb;border-radius:0 0 10px 10px;">'
        . ( $tz_row ? '<table style="width:100%;border-collapse:collapse;margin-bottom:14px;">' . $tz_row . '</table>' : '' )
        . '<table style="width:100%;border-collapse:collapse;">' . $rows . '</table>'
        . '<p style="color:#6b7280;font-size:12px;margin-top:20px;font-family:Plus Jakarta Sans,Arial,sans-serif;">Submitted: ' . current_time('Y-m-d H:i:s') . '</p>'
        . '</div></div></body></html>';

    foreach ($emails as $email) {
    wp_mail($email, $subject, $message, $headers);
}
}
function ssb_send_form_copy( $form, $entry_data, $to_email ) {
    $settings = $form->settings;
    $subject  = 'Your submission to: ' . $form->form_name;
    $headers  = ssb_get_email_headers();

    $rows = '';
    foreach ( $entry_data as $label => $value ) {
        $rows .= '<tr>
            <td style="padding:8px 12px;font-weight:bold;color:#667eea;">' . esc_html($label) . '</td>
            <td style="padding:8px 12px;">' . nl2br(esc_html($value)) . '</td>
        </tr>';
    }

    $message = '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;color:#333;">
    <div style="max-width:600px;margin:0 auto;padding:20px;">
        <div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:24px;border-radius:10px 10px 0 0;color:#fff;">
            <h2 style="margin:0;">✅ We received your message!</h2>
        </div>
        <div style="background:#fff;padding:24px;border:1px solid #e5e7eb;border-radius:0 0 10px 10px;">
            <p>Thank you for contacting us via <strong>' . esc_html($form->form_name) . '</strong>. Here is a copy of what you submitted:</p>
            <table style="width:100%;border-collapse:collapse;background:#f9fafb;border-radius:8px;">' . $rows . '</table>
            <p style="color:#6b7280;font-size:13px;margin-top:16px;">We will get back to you as soon as possible.</p>
        </div>
    </div></body></html>';

    wp_mail( $to_email, $subject, $message, $headers );
}
