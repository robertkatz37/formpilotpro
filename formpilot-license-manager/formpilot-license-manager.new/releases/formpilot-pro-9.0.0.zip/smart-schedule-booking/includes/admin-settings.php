<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'ssb_register_menus' );
function ssb_register_menus() {
    add_menu_page(
        'FormPilot Pro', 'FormPilot Pro', 'manage_options',
        'ssb-bookings', 'ssb_bookings_page', 'dashicons-calendar-alt', 25
    );
    if ( function_exists('ssb_license_can') && ssb_license_can('core') ) {
        add_submenu_page('ssb-bookings','All Bookings','All Bookings','manage_options','ssb-bookings','ssb_bookings_page');
        add_submenu_page('ssb-bookings','Settings','Settings','manage_options','ssb-settings','ssb_settings_page');
    }
    // Form Builder submenu is registered in forms-admin.php → ssb_register_form_menus()
}

add_action( 'admin_enqueue_scripts', 'ssb_admin_assets' );
function ssb_admin_assets( $hook ) {
    if ( strpos($hook, 'ssb-') === false && strpos($hook, 'schedule-booking') === false ) return;
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_enqueue_style('ssb-inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', [], null);
    wp_enqueue_style('ssb-admin-pro', SSB_PLUGIN_URL . 'assets/css/admin-pro.css', ['wp-color-picker'], SSB_VERSION);
    wp_enqueue_script('ssb-admin', SSB_PLUGIN_URL . 'assets/js/admin.js', ['jquery','wp-color-picker'], SSB_VERSION, true);
    wp_localize_script('ssb-admin', 'ssbAdmin', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('ssb_admin_nonce'),
    ]);
    // Inline responsive admin CSS
    wp_add_inline_style('wp-color-picker', '
        /* SSB Admin — Responsive */
        @media (max-width: 960px) {
            .ssb-admin-wrap { max-width: 100% !important; }
            .ssb-two-col, .ssb-compare-grid { grid-template-columns: 1fr !important; }
        }
        @media (max-width: 782px) {
            /* WP already handles admin menu; fix our content */
            .ssb-admin-wrap .form-table th {
                display: block; width: 100%; padding-bottom: 4px;
                padding-top: 16px; font-size: 13px;
            }
            .ssb-admin-wrap .form-table td {
                display: block; width: 100%; padding-top: 0; padding-left: 0;
            }
            .ssb-admin-wrap .form-table input[type="text"],
            .ssb-admin-wrap .form-table input[type="email"],
            .ssb-admin-wrap .form-table input[type="password"],
            .ssb-admin-wrap .form-table input[type="number"],
            .ssb-admin-wrap .form-table select,
            .ssb-admin-wrap .form-table textarea {
                width: 100% !important; max-width: 100% !important;
                font-size: 14px !important; box-sizing: border-box !important;
            }
            .ssb-admin-wrap .regular-text,
            .ssb-admin-wrap .large-text { width: 100% !important; }
            .ssb-admin-wrap .wp-picker-container { width: 100%; }
            .ssb-admin-wrap .wp-picker-container input[type="text"] { width: auto !important; }
            .ssb-admin-wrap p.submit { padding-top: 10px; }
            .ssb-admin-wrap .button-large { width: 100%; text-align: center; box-sizing: border-box; }
            /* Port buttons */
            .ssb-port-btn { margin-top: 6px !important; }
            /* SMTP test row */
            #ssb-test-email-addr { width: 100% !important; margin-bottom: 8px; }
            .ssb-admin-wrap div[style*="display:flex"] { flex-wrap: wrap !important; }
            /* Preview button */
            #ssb-preview-btn { width: 100% !important; text-align: center; }
        }
        @media (max-width: 480px) {
            .ssb-admin-wrap h2 { font-size: 16px !important; }
            .ssb-admin-wrap h3 { font-size: 14px !important; }
            .nav-tab { font-size: 12px !important; padding: 8px 10px !important; }
            .ssb-panel { padding: 18px !important; }
            code { word-break: break-all; }
        }
    ');
}

function ssb_settings_page() {
    if ( ! current_user_can('manage_options') ) return;
    if ( function_exists('ssb_license_admin_guard') && ! ssb_license_admin_guard('core') ) return;

    // Active tab
    $active_tab = sanitize_text_field($_GET['tab'] ?? 'appearance');

    // Notification messages from OAuth callback
    $oauth_msg = sanitize_text_field($_GET['ssb_msg'] ?? '');
    $oauth_err = sanitize_text_field($_GET['ssb_err'] ?? '');

    // Save general settings — only save fields that belong to the current tab's form
    if ( isset($_POST['ssb_save_settings']) && check_admin_referer('ssb_settings_nonce') ) {

        // Appearance tab fields
        $appearance_fields = [
            'ssb_primary_color','ssb_secondary_color','ssb_accent_color','ssb_button_text_color',
            'ssb_border_radius','ssb_font_family','ssb_sidebar_text_color',
        ];

        // Content tab fields
        $content_fields = [
            'ssb_event_title','ssb_event_label','ssb_event_brand_name',
            'ssb_organizer_display_name',
            'ssb_event_duration','ssb_event_description',
            'ssb_logo_letter','ssb_team_label',
        ];

        // Email/SMTP tab fields
        $email_fields = [
            'ssb_support_email','ssb_extra_notify_email',
            'ssb_smtp_host','ssb_smtp_port','ssb_smtp_encryption',
            'ssb_smtp_username','ssb_smtp_password',
            'ssb_smtp_from_email','ssb_smtp_from_name',
        ];

        // Detect which tab was submitted by checking which fields are present in $_POST.
        // Each tab's form only contains its own fields, so we only save what was actually submitted.
        if ( isset($_POST['ssb_primary_color']) ) {
            // Appearance tab submitted
            foreach ( $appearance_fields as $field ) {
                update_option( $field, sanitize_text_field( $_POST[$field] ?? '' ) );
            }
            $active_tab = 'appearance';
        } elseif ( isset($_POST['ssb_event_label']) || isset($_POST['ssb_logo_letter']) ) {
            // Content tab submitted
            foreach ( $content_fields as $field ) {
                if ( $field === 'ssb_event_description' ) {
                    update_option( $field, wp_kses_post( $_POST[$field] ?? '' ) );
                } else {
                    update_option( $field, sanitize_text_field( $_POST[$field] ?? '' ) );
                }
            }
            $active_tab = 'content';
        } elseif ( isset($_POST['ssb_support_email']) || isset($_POST['ssb_smtp_host']) ) {
            // Email/SMTP tab submitted
            foreach ( $email_fields as $field ) {
                update_option( $field, sanitize_text_field( $_POST[$field] ?? '' ) );
            }
            // Checkbox: only present in POST when checked; explicit 0 when unchecked
            update_option( 'ssb_smtp_enabled', isset($_POST['ssb_smtp_enabled']) ? '1' : '0' );
            $active_tab = 'email';
        }

        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }

    // Save Payment settings
    if ( isset($_POST['ssb_save_payment']) && check_admin_referer('ssb_payment_nonce') ) {
        update_option('ssb_payment_enabled',        isset($_POST['ssb_payment_enabled']) ? '1' : '0');
        update_option('ssb_stripe_publishable_key', sanitize_text_field($_POST['ssb_stripe_publishable_key'] ?? ''));
        update_option('ssb_stripe_secret_key',      sanitize_text_field($_POST['ssb_stripe_secret_key'] ?? ''));
        update_option('ssb_stripe_test_mode',       isset($_POST['ssb_stripe_test_mode']) ? '1' : '0');
        update_option('ssb_booking_price',          sanitize_text_field($_POST['ssb_booking_price'] ?? '0'));
        update_option('ssb_booking_currency',       sanitize_text_field($_POST['ssb_booking_currency'] ?? 'USD'));
        update_option('ssb_payment_description',    sanitize_text_field($_POST['ssb_payment_description'] ?? 'Booking deposit'));
        echo '<div class="notice notice-success is-dismissible"><p>Payment settings saved.</p></div>';
        $active_tab = 'payment';
    }

    // Save Google Calendar settings
    if ( isset($_POST['ssb_save_google']) && check_admin_referer('ssb_google_settings_nonce') ) {
        update_option('ssb_google_client_id',     sanitize_text_field($_POST['ssb_google_client_id'] ?? ''));
        update_option('ssb_google_client_secret', sanitize_text_field($_POST['ssb_google_client_secret'] ?? ''));
        update_option('ssb_google_calendar_id',   sanitize_text_field($_POST['ssb_google_calendar_id'] ?? 'primary'));
        update_option('ssb_google_timezone',      sanitize_text_field($_POST['ssb_google_timezone'] ?? 'America/New_York'));
        update_option('ssb_google_meet_enabled',  isset($_POST['ssb_google_meet_enabled']) ? '1' : '0');
        echo '<div class="notice notice-success is-dismissible"><p>Google Calendar settings saved.</p></div>';
        $active_tab = 'google';
    }

    $p  = get_option('ssb_primary_color',     '#667eea');
    $s  = get_option('ssb_secondary_color',   '#764ba2');
    $bt = get_option('ssb_button_text_color', '#ffffff');
    $br = get_option('ssb_border_radius',     '12');
    $ff = get_option('ssb_font_family',       'inherit');
    $st = get_option('ssb_sidebar_text_color','#ffffff');
    ?>
    <div class="wrap ssb-admin-wrap">
        <div class="ssb-page-header">
            <div class="ssb-page-header-left">
                <div class="ssb-page-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
                <div>
                    <h1 class="ssb-page-title">Settings</h1>
                    <p class="ssb-page-subtitle">Configure how FormPilot Pro looks and behaves</p>
                </div>
            </div>
            <div class="ssb-page-header-right">
                <span class="ssb-pill">v<?php echo esc_html(SSB_VERSION); ?></span>
            </div>
        </div>

        <?php if ( $oauth_msg === 'connected' ): ?>
            <div class="notice notice-success is-dismissible"><p>Google Calendar connected successfully. You can now test the connection below.</p></div>
        <?php elseif ( $oauth_msg === 'disconnected' ): ?>
            <div class="notice notice-info is-dismissible"><p>Google Calendar disconnected.</p></div>
        <?php elseif ( $oauth_msg === 'error' ): ?>
            <div class="notice notice-error is-dismissible"><p>Google OAuth error: <?php echo esc_html(urldecode($oauth_err)); ?></p></div>
        <?php elseif ( $oauth_msg === 'invalid_state' ): ?>
            <div class="notice notice-error is-dismissible"><p>Security check failed. Please try connecting again.</p></div>
        <?php endif; ?>

        <!-- Tab nav -->
        <nav class="nav-tab-wrapper">
            <?php
            $tab_icons = [
                'appearance' => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-4"/></svg>',
                'content'    => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>',
                'email'      => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>',
                'google'     => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>',
                'payment'    => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M5 6h14a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2z"/></svg>',
                'shortcode'  => '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16M6 8l-4 4 4 4m12-8l4 4-4 4"/></svg>',
            ];
            $tabs = [
                'appearance' => 'Appearance',
                'content'    => 'Content',
                'email'      => 'Email & SMTP',
                'google'     => 'Google Calendar',
                'payment'    => 'Payments',
                'shortcode'  => 'Shortcode',
            ];
            foreach ( $tabs as $slug => $label ):
                $cls = ($active_tab === $slug) ? 'nav-tab nav-tab-active' : 'nav-tab';
            ?>
                <a href="?page=ssb-settings&tab=<?php echo $slug; ?>" class="<?php echo $cls; ?>"><?php echo $tab_icons[$slug]; ?><?php echo $label; ?></a>
            <?php endforeach; ?>
        </nav>

        <div class="ssb-panel">

        <?php if ( $active_tab === 'appearance' ): ?>
        <!-- ═══════════════════ APPEARANCE ═══════════════════ -->
        <form method="post">
            <?php wp_nonce_field('ssb_settings_nonce'); ?>
            <h2>Appearance Settings</h2>
            <p class="ssb-panel-lead">Match the booking widget to your brand.</p>
            <table class="form-table">
                <tr>
                    <th><label>Primary Color</label></th>
                    <td>
                        <input type="text" name="ssb_primary_color" value="<?php echo esc_attr($p); ?>" class="ssb-color-picker">
                        <p class="description">Used for buttons, selected states, accents</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Secondary / Gradient Color</label></th>
                    <td>
                        <input type="text" name="ssb_secondary_color" value="<?php echo esc_attr($s); ?>" class="ssb-color-picker">
                        <p class="description">Used in gradients alongside primary color</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Button Text Color</label></th>
                    <td><input type="text" name="ssb_button_text_color" value="<?php echo esc_attr($bt); ?>" class="ssb-color-picker"></td>
                </tr>
                <tr>
                    <th><label>Sidebar Text Color</label></th>
                    <td><input type="text" name="ssb_sidebar_text_color" value="<?php echo esc_attr($st); ?>" class="ssb-color-picker"></td>
                </tr>
                <tr>
                    <th><label>Border Radius (px)</label></th>
                    <td>
                        <input type="number" name="ssb_border_radius" value="<?php echo esc_attr($br); ?>" min="0" max="50" class="small-text">
                        <p class="description">0 = sharp corners · 50 = fully rounded</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Font Family</label></th>
                    <td>
                        <select name="ssb_font_family">
                            <?php
                            $fonts = [
                                'inherit'                                                  => 'Theme Default',
                                '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'   => 'System Sans-Serif',
                                'Georgia,serif'                                             => 'Georgia (Serif)',
                                '"Courier New",monospace'                                   => 'Courier New (Mono)',
                                '"Arial",sans-serif'                                        => 'Arial',
                            ];
                            foreach ( $fonts as $val => $label ) {
                                printf('<option value="%s" %s>%s</option>', esc_attr($val), selected($ff,$val,false), esc_html($label));
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            <!-- Live preview -->
            <div class="ssb-preview-block">
                <div>
                    <div class="ssb-preview-label">Live button preview</div>
                    <div id="ssb-preview-btn" style="display:inline-block;margin-top:10px;padding:14px 28px;background:linear-gradient(135deg,<?php echo esc_attr($p); ?>,<?php echo esc_attr($s); ?>);color:<?php echo esc_attr($bt); ?>;border-radius:<?php echo esc_attr($br); ?>px;font-weight:700;font-size:16px;font-family:<?php echo esc_attr($ff); ?>;cursor:pointer;border:none;">Schedule Meeting</div>
                </div>
            </div>
            <p class="submit"><input type="submit" name="ssb_save_settings" class="button button-primary button-large" value="Save Appearance"></p>
        </form>

        <?php elseif ( $active_tab === 'content' ): ?>
        <!-- ═══════════════════ CONTENT ═══════════════════ -->
        <form method="post">
            <?php wp_nonce_field('ssb_settings_nonce'); ?>
            <h2>Booking Form &amp; Calendar Content</h2>
            <p class="ssb-panel-lead">Control what clients see on the booking form and in their calendar invite.</p>

            <!-- Calendar event naming explained -->
            <div class="ssb-alert ssb-alert-info">
                <h4>How calendar event titles work</h4>
                <div class="ssb-compare-grid">
                    <div class="ssb-compare-card">
                        <b>Your calendar (organizer)</b>
                        <span>You see the client's name so you know who each call is with:</span>
                        <code>Discovery Call — John Smith</code>
                    </div>
                    <div class="ssb-compare-card">
                        <b>Client's invite email</b>
                        <span>Client sees your brand name — looks professional:</span>
                        <code>Discovery Call — Your Brand</code>
                    </div>
                </div>
            </div>

            <table class="form-table">
                <tr>
                    <th><label for="ssb_event_label">Event Label</label></th>
                    <td>
                        <input type="text" id="ssb_event_label" name="ssb_event_label"
                               value="<?php echo esc_attr(get_option('ssb_event_label','Discovery Call')); ?>"
                               class="regular-text" placeholder="Discovery Call">
                        <p class="description">The first part of the title — e.g. <strong>Discovery Call</strong>, Strategy Session, Consultation</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_event_brand_name">Your Brand Name</label></th>
                    <td>
                        <input type="text" id="ssb_event_brand_name" name="ssb_event_brand_name"
                               value="<?php echo esc_attr(get_option('ssb_event_brand_name', get_bloginfo('name'))); ?>"
                               class="regular-text" placeholder="Your Brand">
                        <p class="description">Shown on the client's calendar invite — e.g. <strong>Your Brand</strong>. Makes the invite look branded and professional.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_organizer_display_name">Organizer Display Name</label></th>
                    <td>
                        <input type="text" id="ssb_organizer_display_name" name="ssb_organizer_display_name"
                               value="<?php echo esc_attr(get_option('ssb_organizer_display_name', get_bloginfo('name'))); ?>"
                               class="regular-text" placeholder="Support Team">
                        <p class="description">
                            The name shown as the <strong>event organizer</strong> in the client's invite email — replaces "unknown sender".<br>
                            <span style="color:#dc2626;font-weight:600;">For best results:</span> Also update your Google Account name at
                            <a href="https://myaccount.google.com/name" target="_blank">myaccount.google.com/name</a> to match this.
                        </p>
                    </td>
                </tr>
            </table>

            <div class="ssb-alert ssb-alert-warning">
                <h4>Why does Google show "Invitation from unknown sender"?</h4>
                <p>
                    Google flags calendar invites as "unknown sender" when the Google account sending them hasn't established trust with the recipient's Gmail.
                    This is a <strong>Google security feature</strong>, not a plugin issue. To fix it permanently:
                </p>
                <ol style="margin:10px 0 0;padding-left:18px;line-height:1.9;">
                    <li>Go to <a href="https://myaccount.google.com/name" target="_blank">myaccount.google.com/name</a> — set your account name to <strong>"<?php echo esc_html(get_option('ssb_organizer_display_name', get_bloginfo('name'))); ?>"</strong></li>
                    <li>Go to <a href="https://myaccount.google.com/profile" target="_blank">myaccount.google.com/profile</a> — add your organization/company name</li>
                    <li>In Google Cloud Console → OAuth consent screen → set the <strong>App name</strong> to your brand name and upload a <strong>logo</strong></li>
                    <li>If your app is in <em>Testing</em> mode, move it to <strong>Production</strong> (publish the OAuth app) — testing-mode apps always show as "unknown"</li>
                    <li>Ask a few clients to click <strong>"Yes"</strong> on the invite — over time Google learns to trust the sender</li>
                </ol>
            </div>

            <h3>Booking Form Display</h3>
            <table class="form-table">
                <tr>
                    <th><label>Logo Letter</label></th>
                    <td>
                        <input type="text" name="ssb_logo_letter" value="<?php echo esc_attr(get_option('ssb_logo_letter','P')); ?>" maxlength="2" class="small-text">
                        <p class="description">Single letter shown in the sidebar logo box</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Team Label</label></th>
                    <td><input type="text" name="ssb_team_label" value="<?php echo esc_attr(get_option('ssb_team_label','Team')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>Duration</label></th>
                    <td><input type="text" name="ssb_event_duration" value="<?php echo esc_attr(get_option('ssb_event_duration','30 Minutes')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>Session Description</label></th>
                    <td>
                        <?php
                        wp_editor(
                            get_option('ssb_event_description',''),
                            'ssb_event_description',
                            [
                                'textarea_name' => 'ssb_event_description',
                                'textarea_rows' => 6,
                                'media_buttons' => false,
                                'teeny'         => true,
                                'quicktags'     => true,
                            ]
                        );
                        ?>
                        <p class="description">Shown in the booking form sidebar and included in the calendar event description</p>
                    </td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="ssb_save_settings" class="button button-primary button-large" value="Save Content Settings"></p>
        </form>

        <?php elseif ( $active_tab === 'email' ): ?>
        <!-- ═══════════════════ EMAIL & SMTP ═══════════════════ -->
        <form method="post">
            <?php wp_nonce_field('ssb_settings_nonce'); ?>
            <?php
            $smtp_enabled = get_option('ssb_smtp_enabled') === '1';
            $smtp_host    = get_option('ssb_smtp_host', '');
            $can_reach    = null;
            if ( $smtp_enabled && $smtp_host ) {
                $conn = @fsockopen($smtp_host, (int)get_option('ssb_smtp_port',587), $errno, $errstr, 3);
                $can_reach = (bool) $conn;
                if ( $conn ) fclose($conn);
            }
            ?>
            <?php if ( $smtp_enabled && $smtp_host && $can_reach === false ): ?>
            <div class="ssb-alert ssb-alert-danger">
                <strong>Cannot reach SMTP host on port <?php echo esc_html(get_option('ssb_smtp_port','587')); ?>.</strong><br>
                Your server may be blocking outbound SMTP. Try port 465+SSL, or use a transactional email service.
            </div>
            <?php elseif ( $smtp_enabled && $smtp_host && $can_reach ): ?>
            <div class="ssb-alert ssb-alert-success">
                <strong>SMTP host reachable.</strong> Click "Send Test Email" below to verify credentials.
            </div>
            <?php endif; ?>

            <h2>Notification Settings</h2>
            <table class="form-table">
                <tr>
                    <th><label>Primary Notify Email</label></th>
                    <td>
                        <input type="email" name="ssb_support_email" value="<?php echo esc_attr(get_option('ssb_support_email','')); ?>" class="regular-text">
                        <p class="description">Receives booking notifications — e.g. <code>support@example.com</code></p>
                    </td>
                </tr>
                <tr>
                    <th><label>Extra Notify Email</label></th>
                    <td>
                        <input type="email" name="ssb_extra_notify_email" value="<?php echo esc_attr(get_option('ssb_extra_notify_email','')); ?>" class="regular-text" placeholder="info@example.com">
                        <p class="description">
                            <strong>Second email address</strong> that also receives every booking notification.<br>
                            Both <code>support@</code> and <code>info@</code> will each get a full copy. Leave blank to send to Primary only.
                        </p>
                    </td>
                </tr>
            </table>

            <h3>SMTP Settings</h3>
            <table class="form-table">
                <tr>
                    <th><label>Enable SMTP</label></th>
                    <td>
                        <div class="ssb-toggle-row">
                            <label class="ssb-switch">
                                <input type="checkbox" name="ssb_smtp_enabled" value="1" <?php checked(get_option('ssb_smtp_enabled'),'1'); ?>>
                                <span class="ssb-switch-track"></span>
                            </label>
                            <div class="ssb-toggle-copy"><strong>Use SMTP instead of WordPress default mail</strong></div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th><label>SMTP Host</label></th>
                    <td>
                        <input type="text" id="ssb_smtp_host" name="ssb_smtp_host" value="<?php echo esc_attr(get_option('ssb_smtp_host','')); ?>" class="regular-text" placeholder="mail.privateemail.com">
                        <p class="description">Namecheap: <code>mail.privateemail.com</code> · Gmail: <code>smtp.gmail.com</code></p>
                    </td>
                </tr>
                <tr>
                    <th><label>SMTP Port</label></th>
                    <td>
                        <input type="number" id="ssb_smtp_port" name="ssb_smtp_port" value="<?php echo esc_attr(get_option('ssb_smtp_port','587')); ?>" class="small-text">
                        &nbsp;
                        <button type="button" class="button button-small ssb-port-btn" data-port="587" data-enc="tls">587 + TLS</button>
                        <button type="button" class="button button-small ssb-port-btn" data-port="465" data-enc="ssl" style="margin-left:4px;">465 + SSL</button>
                    </td>
                </tr>
                <tr>
                    <th><label>Encryption</label></th>
                    <td>
                        <select id="ssb_smtp_encryption" name="ssb_smtp_encryption">
                            <option value="tls" <?php selected(get_option('ssb_smtp_encryption','tls'),'tls'); ?>>TLS (port 587 recommended)</option>
                            <option value="ssl" <?php selected(get_option('ssb_smtp_encryption','tls'),'ssl'); ?>>SSL (port 465)</option>
                            <option value="none" <?php selected(get_option('ssb_smtp_encryption','tls'),'none'); ?>>None (not recommended)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label>SMTP Username</label></th>
                    <td><input type="text" id="ssb_smtp_username" name="ssb_smtp_username" value="<?php echo esc_attr(get_option('ssb_smtp_username','')); ?>" class="regular-text" placeholder="you@yourdomain.com"></td>
                </tr>
                <tr>
                    <th><label>SMTP Password</label></th>
                    <td><input type="password" name="ssb_smtp_password" value="<?php echo esc_attr(get_option('ssb_smtp_password','')); ?>" class="regular-text" autocomplete="new-password"></td>
                </tr>
                <tr>
                    <th><label>From Email</label></th>
                    <td><input type="email" name="ssb_smtp_from_email" value="<?php echo esc_attr(get_option('ssb_smtp_from_email','')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label>From Name</label></th>
                    <td><input type="text" name="ssb_smtp_from_name" value="<?php echo esc_attr(get_option('ssb_smtp_from_name','')); ?>" class="regular-text"></td>
                </tr>
            </table>

            <div class="ssb-preview-block" style="border-style:solid;">
                <div style="width:100%;">
                    <div class="ssb-preview-label">Test SMTP connection</div>
                    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px;">
                        <input type="email" id="ssb-test-email-addr" placeholder="Send test to…" class="regular-text" value="<?php echo esc_attr(get_option('admin_email')); ?>">
                        <button type="button" id="ssb-test-smtp" class="button button-primary">Send Test Email</button>
                    </div>
                    <div id="ssb-test-result" class="ssb-result-banner" style="display:none;"></div>
                </div>
            </div>

            <p class="submit"><input type="submit" name="ssb_save_settings" class="button button-primary button-large" value="Save Email Settings"></p>
        </form>

        <?php elseif ( $active_tab === 'google' ): ?>
        <!-- ═══════════════════ GOOGLE CALENDAR ═══════════════════ -->
        <?php
        $is_connected = ssb_google_is_connected();
        $auth_url     = ssb_google_get_auth_url();
        ?>

        <div class="ssb-compare-grid" style="margin-top:0;margin-bottom:26px;gap:20px;">
            <!-- Status card -->
            <div class="ssb-alert <?php echo $is_connected ? 'ssb-alert-success' : 'ssb-alert-danger'; ?>" style="margin-bottom:0;">
                <h4 style="font-size:15px;">
                    <?php echo $is_connected ? 'Connected to Google Calendar' : 'Not Connected'; ?>
                </h4>
                <p>
                    <?php if ( $is_connected ): ?>
                        Calendar ID: <strong><?php echo esc_html(get_option('ssb_google_calendar_id','primary')); ?></strong><br>
                        Google Meet: <strong><?php echo get_option('ssb_google_meet_enabled','1') === '1' ? 'Enabled' : 'Disabled'; ?></strong>
                    <?php else: ?>
                        Complete the setup below to enable Google Calendar sync and automatic Google Meet links.
                    <?php endif; ?>
                </p>
                <?php if ( $is_connected ): ?>
                <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="button" id="ssb-test-google" class="button button-primary">Test Connection</button>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ssb-settings&tab=google&ssb_google_callback=1&ssb_google_disconnect=1'),'ssb_google_disconnect'); ?>"
                       class="button" onclick="return confirm('Disconnect Google Calendar?')">Disconnect</a>
                </div>
                <div id="ssb-google-test-result" class="ssb-result-banner" style="display:none;"></div>
                <?php endif; ?>
            </div>

            <!-- How it works -->
            <div class="ssb-alert ssb-alert-info" style="margin-bottom:0;">
                <h4 style="font-size:15px;">What this does</h4>
                <ul style="margin:0;padding-left:18px;line-height:1.8;">
                    <li>Automatically creates Google Calendar events on every booking</li>
                    <li>Generates a <strong>Google Meet link</strong> for each session</li>
                    <li>Sends Meet link in confirmation emails to customers</li>
                    <li>Invites the customer to the calendar event</li>
                    <li>Sets reminders: 24h email + 15min popup</li>
                </ul>
            </div>
        </div>

        <!-- Step-by-step setup guide -->
        <?php if ( ! $is_connected ): ?>
        <div class="ssb-alert ssb-alert-warning" style="padding:24px;">
            <h4 style="font-size:14px;margin-bottom:16px;">Setup guide — 3 easy steps</h4>

            <div style="display:grid;grid-template-columns:36px 1fr;gap:12px;align-items:start;margin-bottom:16px;">
                <div style="width:32px;height:32px;background:var(--ssb-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:14px;">1</div>
                <div>
                    <strong>Create Google Cloud Project &amp; Enable Calendar API</strong>
                    <ol style="margin:6px 0 0;padding-left:18px;font-size:13px;color:#6b7280;line-height:1.8;">
                        <li>Go to <a href="https://console.cloud.google.com/" target="_blank">console.cloud.google.com</a> → Create Project</li>
                        <li>Enable <strong>Google Calendar API</strong> (APIs &amp; Services → Enable APIs)</li>
                        <li>Go to <strong>APIs &amp; Services → OAuth consent screen</strong></li>
                        <li>Set User Type: <strong>External</strong> → Fill App name &amp; your email</li>
                        <li>Add scope: <code>https://www.googleapis.com/auth/calendar</code></li>
                        <li>Add your Google account as a <strong>Test User</strong></li>
                    </ol>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:36px 1fr;gap:12px;align-items:start;margin-bottom:16px;">
                <div style="width:32px;height:32px;background:var(--ssb-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:14px;">2</div>
                <div>
                    <strong>Create OAuth 2.0 Credentials</strong>
                    <ol style="margin:6px 0 0;padding-left:18px;font-size:13px;color:#6b7280;line-height:1.8;">
                        <li>APIs &amp; Services → Credentials → Create Credentials → <strong>OAuth 2.0 Client ID</strong></li>
                        <li>Application type: <strong>Web application</strong></li>
                        <li>Add Authorized Redirect URI:<br>
                            <code style="background:#fff;padding:4px 8px;border-radius:4px;border:1px solid #e5e7eb;font-size:12px;display:inline-block;margin-top:4px;word-break:break-all;">
                                <?php echo esc_url(ssb_google_redirect_uri()); ?>
                            </code>
                        </li>
                        <li>Copy your <strong>Client ID</strong> and <strong>Client Secret</strong> into the fields below</li>
                    </ol>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:36px 1fr;gap:12px;align-items:start;">
                <div style="width:32px;height:32px;background:var(--ssb-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:14px;">3</div>
                <div>
                    <strong>Save Settings &amp; Click Connect</strong>
                    <p style="margin:4px 0 0;font-size:13px;color:#6b7280;">Enter your Client ID &amp; Secret below, save, then click the <em>Connect to Google Calendar</em> button.</p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Google Calendar settings form -->
        <form method="post">
            <?php wp_nonce_field('ssb_google_settings_nonce'); ?>
            <h2>API Credentials</h2>
            <table class="form-table">
                <tr>
                    <th><label for="ssb_google_client_id">Client ID</label></th>
                    <td>
                        <input type="text" id="ssb_google_client_id" name="ssb_google_client_id"
                               value="<?php echo esc_attr(get_option('ssb_google_client_id','')); ?>"
                               class="large-text" placeholder="xxxxxxxxxx.apps.googleusercontent.com">
                        <p class="description">Found in Google Cloud Console → APIs &amp; Services → Credentials</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_google_client_secret">Client Secret</label></th>
                    <td>
                        <input type="password" id="ssb_google_client_secret" name="ssb_google_client_secret"
                               value="<?php echo esc_attr(get_option('ssb_google_client_secret','')); ?>"
                               class="regular-text" autocomplete="new-password">
                        <p class="description">Keep this secret — never share it publicly</p>
                    </td>
                </tr>
            </table>

            <h3>Calendar Settings</h3>
            <table class="form-table">
                <tr>
                    <th><label for="ssb_google_calendar_id">Calendar ID</label></th>
                    <td>
                        <input type="text" id="ssb_google_calendar_id" name="ssb_google_calendar_id"
                               value="<?php echo esc_attr(get_option('ssb_google_calendar_id','primary')); ?>"
                               class="regular-text" placeholder="primary">
                        <p class="description">Use <code>primary</code> for your main calendar, or find your Calendar ID in Google Calendar Settings → your calendar → Calendar ID</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_google_timezone">Event Timezone</label></th>
                    <td>
                        <select id="ssb_google_timezone" name="ssb_google_timezone">
                            <?php
                            $tz_saved = get_option('ssb_google_timezone', 'America/New_York');
                            $tz_list  = [
                                'America/New_York'    => 'Eastern (ET)',
                                'America/Chicago'     => 'Central (CT)',
                                'America/Denver'      => 'Mountain (MT)',
                                'America/Los_Angeles' => 'Pacific (PT)',
                                'America/Phoenix'     => 'Arizona (no DST)',
                                'America/Anchorage'   => 'Alaska (AKT)',
                                'Pacific/Honolulu'    => 'Hawaii (HT)',
                                'Europe/London'       => 'London (GMT/BST)',
                                'Europe/Paris'        => 'Paris (CET)',
                                'Europe/Berlin'       => 'Berlin (CET)',
                                'Asia/Karachi'        => 'Karachi (PKT)',
                                'Asia/Kolkata'        => 'India (IST)',
                                'Asia/Dubai'          => 'Dubai (GST)',
                                'Asia/Singapore'      => 'Singapore (SGT)',
                                'Asia/Tokyo'          => 'Tokyo (JST)',
                                'Australia/Sydney'    => 'Sydney (AEST)',
                                'UTC'                 => 'UTC',
                            ];
                            foreach ( $tz_list as $tz_val => $tz_label ) {
                                printf('<option value="%s" %s>%s</option>', esc_attr($tz_val), selected($tz_saved,$tz_val,false), esc_html($tz_label));
                            }
                            ?>
                        </select>
                        <p class="description">Timezone used when creating Google Calendar events</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Google Meet Links</label></th>
                    <td>
                        <div class="ssb-toggle-row">
                            <label class="ssb-switch">
                                <input type="checkbox" name="ssb_google_meet_enabled" value="1" <?php checked(get_option('ssb_google_meet_enabled','1'),'1'); ?>>
                                <span class="ssb-switch-track"></span>
                            </label>
                            <div class="ssb-toggle-copy">
                                <strong>Automatically generate Google Meet link for each booking</strong>
                                <span>The Meet link is included in the calendar invite and confirmation email</span>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>

            <p class="submit" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                <input type="submit" name="ssb_save_google" class="button button-primary button-large" value="Save Google Settings">
                <?php if ( ! $is_connected && $auth_url ): ?>
                    <a href="<?php echo esc_url($auth_url); ?>" class="button button-large" style="background:#4285f4;color:#fff;border-color:#3367d6;display:inline-flex;align-items:center;gap:8px;">
                        <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#fff" d="M44.5 20H24v8.5h11.7C34.2 33.6 29.7 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 6 1.1 8.1 3l6-6C34.6 5.1 29.5 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21c10.9 0 20-7.9 20-21 0-1.3-.2-2.7-.5-4z"/></svg>
                        Connect to Google Calendar
                    </a>
                <?php elseif ( $is_connected && $auth_url ): ?>
                    <a href="<?php echo esc_url($auth_url); ?>" class="button" title="Re-authorize if you're having issues">Re-authorize</a>
                <?php elseif ( ! $auth_url ): ?>
                    <span style="color:var(--ssb-danger);font-size:13px;">Enter Client ID above and save first to enable Connect button.</span>
                <?php endif; ?>
            </p>
        </form>

        <?php elseif ( $active_tab === 'payment' ): ?>
        <!-- ═══════════════════ PAYMENT ═══════════════════ -->
        <h2>Payment Settings (Stripe)</h2>
        <p class="ssb-panel-lead">Collect a booking deposit via Stripe. Customers pay directly on the booking form before their slot is confirmed.</p>
        <form method="post">
            <?php wp_nonce_field('ssb_payment_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th>Enable Payments</th>
                    <td>
                        <div class="ssb-toggle-row">
                            <label class="ssb-switch">
                                <input type="checkbox" name="ssb_payment_enabled" value="1" <?php checked(get_option('ssb_payment_enabled','0'),'1'); ?>>
                                <span class="ssb-switch-track"></span>
                            </label>
                            <div class="ssb-toggle-copy">
                                <strong>Require payment to confirm a booking</strong>
                                <span>When enabled, the Stripe card form appears on Step 2. Booking is only confirmed after successful payment.</span>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th>Test Mode</th>
                    <td>
                        <div class="ssb-toggle-row">
                            <label class="ssb-switch">
                                <input type="checkbox" name="ssb_stripe_test_mode" value="1" <?php checked(get_option('ssb_stripe_test_mode','1'),'1'); ?>>
                                <span class="ssb-switch-track"></span>
                            </label>
                            <div class="ssb-toggle-copy">
                                <strong>Use Stripe test keys (sandbox)</strong>
                                <span>Disable when you're ready to accept real payments. Use <code>4242 4242 4242 4242</code> to test.</span>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_stripe_publishable_key">Publishable Key</label></th>
                    <td>
                        <input type="text" id="ssb_stripe_publishable_key" name="ssb_stripe_publishable_key" class="regular-text" value="<?php echo esc_attr(get_option('ssb_stripe_publishable_key','')); ?>" placeholder="pk_test_...">
                        <p class="description">Starts with <code>pk_test_</code> (test) or <code>pk_live_</code> (live). Found in your <a href="https://dashboard.stripe.com/apikeys" target="_blank">Stripe Dashboard → API Keys</a>.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_stripe_secret_key">Secret Key</label></th>
                    <td>
                        <input type="password" id="ssb_stripe_secret_key" name="ssb_stripe_secret_key" class="regular-text" value="<?php echo esc_attr(get_option('ssb_stripe_secret_key','')); ?>" placeholder="sk_test_...">
                        <p class="description">Keep this secret. Never share or expose it publicly. Starts with <code>sk_test_</code> or <code>sk_live_</code>.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_booking_price">Booking Price</label></th>
                    <td>
                        <input type="number" id="ssb_booking_price" name="ssb_booking_price" class="small-text" min="0" step="0.01" value="<?php echo esc_attr(get_option('ssb_booking_price','0')); ?>">
                        <p class="description">Amount in the selected currency. Set to 0 to make it free (payment form hidden).</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_booking_currency">Currency</label></th>
                    <td>
                        <select id="ssb_booking_currency" name="ssb_booking_currency">
                            <?php
                            $saved_curr = get_option('ssb_booking_currency','USD');
                            $currencies = ['USD'=>'USD — US Dollar','EUR'=>'EUR — Euro','GBP'=>'GBP — British Pound','CAD'=>'CAD — Canadian Dollar','AUD'=>'AUD — Australian Dollar','PKR'=>'PKR — Pakistani Rupee','INR'=>'INR — Indian Rupee','SGD'=>'SGD — Singapore Dollar','AED'=>'AED — UAE Dirham'];
                            foreach($currencies as $code => $label) printf('<option value="%s" %s>%s</option>', esc_attr($code), selected($saved_curr,$code,false), esc_html($label));
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="ssb_payment_description">Payment Description</label></th>
                    <td>
                        <input type="text" id="ssb_payment_description" name="ssb_payment_description" class="regular-text" value="<?php echo esc_attr(get_option('ssb_payment_description','Booking deposit')); ?>">
                        <p class="description">Shown in Stripe dashboard as the payment description.</p>
                    </td>
                </tr>
            </table>
            <div class="ssb-alert ssb-alert-warning" style="max-width:620px;">
                <h4>How to get your Stripe keys</h4>
                <ol style="margin:8px 0 0;padding-left:20px;line-height:1.8;">
                    <li>Log in to <a href="https://dashboard.stripe.com" target="_blank">dashboard.stripe.com</a></li>
                    <li>Go to <strong>Developers → API Keys</strong></li>
                    <li>Copy the <strong>Publishable key</strong> and <strong>Secret key</strong></li>
                    <li>Paste them above and save</li>
                </ol>
            </div>
            <p class="submit">
                <input type="submit" name="ssb_save_payment" class="button button-primary button-large" value="Save Payment Settings">
            </p>
        </form>

        <?php elseif ( $active_tab === 'shortcode' ): ?>
        <!-- ═══════════════════ SHORTCODE ═══════════════════ -->
        <h2>Shortcodes</h2>
        <p class="ssb-panel-lead">Drop these into any page or post to display your booking tools.</p>
        <div class="ssb-shortcode-card">
            <h3>Main Booking Calendar</h3>
            <div class="ssb-code-chip">[smart_schedule_booking]<span class="ssb-copy-hint">Click to select</span></div>
        </div>
        <div class="ssb-shortcode-card">
            <h3>Custom Form Builder</h3>
            <div class="ssb-code-chip">[ssb_form id="1"]<span class="ssb-copy-hint">Click to select</span></div>
            <p class="description" style="margin-top:10px;">Replace <code>1</code> with your form ID from the Form Builder.</p>
        </div>
        <?php endif; ?>

        </div><!-- end tab panel -->
    </div>
    <?php
}
