<?php
if ( ! defined('ABSPATH') ) exit;

/** FormPilot free-tier policy. No license is required for the free tier. */
function ssb_free_limits(){
    return [
        'forms' => 1,
        'entries_month' => 25,
        'templates' => 3,
        'event_types' => 1,
        'bookings_month' => 10,
        'calendar' => false,
        'stripe' => false,
        'payment_links' => false,
        'advanced_styling' => false,
        'branding' => false,
        'analytics' => false,
        'routing' => false,
        'workflows' => false,
        'team_scheduling' => false,
    ];
}
function ssb_is_paid(){
    return function_exists('ssb_license_status') && !empty(ssb_license_status()['active']) && !empty(ssb_license_key());
}
function ssb_free_form_count(){
    global $wpdb; $table=$wpdb->prefix.'ssb_forms';
    if(!$wpdb->get_var("SHOW TABLES LIKE '$table'")) return 0;
    return (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status <> 'trash'");
}
function ssb_free_entries_this_month(){
    global $wpdb; $table=$wpdb->prefix.'ssb_form_entries';
    if(!$wpdb->get_var("SHOW TABLES LIKE '$table'")) return 0;
    $start = wp_date('Y-m-01 00:00:00');
    return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE created_at >= %s",$start));
}
function ssb_free_can($feature){
    $l=ssb_free_limits(); return isset($l[$feature]) ? (bool)$l[$feature] : false;
}
function ssb_feature_locked_message($feature){
    $names=['calendar'=>'Google Calendar & Meet','stripe'=>'Stripe payments','payment_links'=>'Payment links','advanced_styling'=>'Advanced styling','analytics'=>'Analytics','routing'=>'Routing forms','workflows'=>'Automations / workflows','team_scheduling'=>'Team scheduling'];
    $name=$names[$feature]??ucwords(str_replace('_',' ',$feature));
    return sprintf('%s is a Pro feature. Activate a FormPilot license to unlock it.',$name);
}
function ssb_free_limit_notice($type='forms'){
    $l=ssb_free_limits();
    if($type==='forms') return 'The free plan allows 1 form. Activate FormPilot Pro for unlimited forms and premium templates.';
    if($type==='event_types') return 'The free plan includes 1 event type and one-on-one scheduling. Activate FormPilot Pro for advanced scheduling.';
    if($type==='bookings') return 'The free plan includes 10 bookings per month. Activate FormPilot Pro for higher limits.';
    if($type==='entries') return 'The free plan allows 25 submissions per month. Activate FormPilot Pro for higher limits.';
    return 'This feature is available with FormPilot Pro.';
}
