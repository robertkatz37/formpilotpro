/**
 * FormPilot Pro — Form Builder Admin JS
 */
jQuery(document).ready(function ($) {
    if (!$('#ssb-drop-zone').length) return; // only run on builder page

    /* ── State ─────────────────────────────────────────────────────────────── */
    var fields   = window.ssbInitialFields   || [];
    var settings = window.ssbInitialSettings || {};
    var activeId = null; // currently selected field id

    function builderToast(message, type) {
        var $t = $('#ssb-builder-toast');
        if (!$t.length) { $t = $('<div id="ssb-builder-toast"></div>').appendTo('body'); }
        $t.removeClass('success error').addClass(type || 'success').text(message).stop(true,true).fadeIn(150);
        clearTimeout(window.ssbBuilderToastTimer);
        window.ssbBuilderToastTimer = setTimeout(function(){ $t.fadeOut(220); }, 2600);
    }

    var FIELD_DEFAULTS = {
        text:     { label:'Text Field',     placeholder:'Enter text…',         options:[], width:'full' },
        email:    { label:'Email Address',  placeholder:'your@email.com',      options:[], width:'full' },
        phone:    { label:'Phone Number',   placeholder:'',                    options:[], width:'full', enable_country_code:true },
        number:   { label:'Number',         placeholder:'0',                   options:[], width:'half' },
        textarea: { label:'Message',        placeholder:'Type your message…',  options:[], width:'full' },
        select:   { label:'Select Option',  placeholder:'Choose one…',         options:['Option 1','Option 2','Option 3'], width:'full' },
        radio:    { label:'Choose One',     placeholder:'',                    options:['Option A','Option B','Option C'], width:'full' },
        checkbox: { label:'Select All That Apply', placeholder:'',            options:['Choice 1','Choice 2','Choice 3'], width:'full' },
        date:     { label:'Date',           placeholder:'',                    options:[], width:'half', disable_past:true },
        timeslot: { label:'Preferred Time Slot', placeholder:'',              options:['9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM'], width:'full' },
        time:     { label:'Preferred Time', placeholder:'', options:[], width:'half' },
        timezone: { label:'Your Timezone',  placeholder:'',                    options:[], width:'full' },
        url:      { label:'Website URL',    placeholder:'https://',            options:[], width:'full' },
        heading:  { label:'Section Heading',placeholder:'',                    options:[], width:'full' },
        divider:  { label:'Divider',        placeholder:'',                    options:[], width:'full' },
    };

    var TEMPLATES = {
        contact: [
            { type:'text',     label:'First Name',    placeholder:'', required:true,  width:'half', options:[], help_text:'' },
            { type:'text',     label:'Last Name',     placeholder:'', required:true,  width:'half', options:[], help_text:'' },
            { type:'email',    label:'Email Address', placeholder:'your@email.com', required:true,  width:'full', options:[], help_text:'' },
            { type:'phone',    label:'Phone Number',  placeholder:'+1 234 567 8900', required:false, width:'full', options:[], help_text:'' },
            { type:'text',     label:'Subject',       placeholder:'How can we help?', required:true, width:'full', options:[], help_text:'' },
            { type:'textarea', label:'Message',       placeholder:'Tell us more…', required:true, width:'full', options:[], help_text:'' },
        ],
        lead: [
            { type:'text',  label:'Full Name',     placeholder:'Your name', required:true,  width:'full', options:[], help_text:'' },
            { type:'email', label:'Email Address', placeholder:'your@email.com', required:true,  width:'full', options:[], help_text:'' },
            { type:'phone', label:'Phone Number',  placeholder:'+1 234 567 8900', required:true, width:'full', options:[], help_text:'' },
            { type:'select',label:'Budget Range',  placeholder:'Select budget…', required:false, width:'full',
              options:['Under $1,000','$1,000–$5,000','$5,000–$10,000','Over $10,000'], help_text:'' },
            { type:'textarea', label:'Tell us about your project', placeholder:'', required:false, width:'full', options:[], help_text:'' },
        ],
        survey: [
            { type:'heading',  label:'Survey: Your Feedback',  placeholder:'', required:false, width:'full', options:[], help_text:'' },
            { type:'text',     label:'Your Name',              placeholder:'', required:false, width:'full', options:[], help_text:'' },
            { type:'radio',    label:'Overall Satisfaction',   placeholder:'', required:true,  width:'full',
              options:['Very Satisfied','Satisfied','Neutral','Dissatisfied'], help_text:'' },
            { type:'radio',    label:'Would you recommend us?',placeholder:'', required:true,  width:'full',
              options:['Definitely','Probably','Not Sure','No'], help_text:'' },
            { type:'textarea', label:'Any additional comments?',placeholder:'',required:false, width:'full', options:[], help_text:'' },
        ],
    };

    var ICONS = {
        text:'📝', email:'📧', phone:'📞', number:'🔢', textarea:'📄',
        select:'📋', radio:'⚪', checkbox:'☑️', date:'📅', url:'🔗',
        heading:'🔤', divider:'➖', timeslot:'🕐', time:'⏰', timezone:'🌍'
    };

    /* ── Unique ID ──────────────────────────────────────────────────────────── */
    function uid() { return 'f' + Math.random().toString(36).substr(2,8); }

    /* ── Render drop zone ───────────────────────────────────────────────────── */
    function renderCanvas() {
        var $zone = $('#ssb-drop-zone');
        $zone.empty();

        if (!fields.length) {
            $zone.append('<li class="ssb-drop-placeholder" id="ssb-empty-hint"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v16m8-8H4"/></svg>Click a field type on the left to add it here,<br>or choose a template to start quickly.</li>');
        }

        fields.forEach(function (f) {
            $zone.append(buildFieldBlock(f));
        });

        initSortable();
        updateCount();
        renderPreview();
    }

    function buildFieldBlock(f) {
        var isActive  = f.id === activeId;
        var reqDot    = f.required ? 'visible' : '';
        var typeLabel = f.type.charAt(0).toUpperCase() + f.type.slice(1);
        var icon      = ICONS[f.type] || '📝';

        var $li = $('<li>')
            .addClass('ssb-field-block' + (isActive ? ' active' : ''))
            .attr('data-id', f.id);

        $li.html(
            '<div class="ssb-field-block-header">' +
            '  <span class="ssb-field-drag-handle">⠿</span>' +
            '  <span class="ssb-field-type-badge">' + icon + ' ' + typeLabel + '</span>' +
            '  <span class="ssb-field-label-preview">' + (f.label || 'Untitled') + '</span>' +
            '  <span class="ssb-field-required-dot ' + reqDot + '" title="Required"></span>' +
            '  <div class="ssb-field-actions">' +
            '    <button class="ssb-field-btn dup" title="Duplicate" data-id="' + f.id + '">⧉</button>' +
            '    <button class="ssb-field-btn del" title="Delete" data-id="' + f.id + '">✕</button>' +
            '  </div>' +
            '</div>'
        );

        $li.on('click', function (e) {
            if ($(e.target).hasClass('ssb-field-btn')) return;
            selectField(f.id);
        });

        $li.find('.del').on('click', function (e) {
            e.stopPropagation();
            if (!confirm('Delete this field?')) return;
            fields = fields.filter(function(x){ return x.id !== f.id; });
            if (activeId === f.id) { activeId = null; showFieldInspectorEmpty(); }
        
        });

        $li.find('.dup').on('click', function (e) {
            e.stopPropagation();
            var orig  = fields.find(function(x){ return x.id === f.id; });
            var clone = JSON.parse(JSON.stringify(orig));
            clone.id  = uid();
            clone.label += ' (copy)';
            var idx = fields.findIndex(function(x){ return x.id === f.id; });
            fields.splice(idx + 1, 0, clone);
        
        });

        return $li;
    }

    /* ── Sortable ───────────────────────────────────────────────────────────── */
    function initSortable() {
        $('#ssb-drop-zone').sortable({
            handle:      '.ssb-field-drag-handle',
            placeholder: 'ssb-field-block',
            tolerance:   'pointer',
            forcePlaceholderSize: true,
            update: function () {
                var newOrder = [];
                $('#ssb-drop-zone .ssb-field-block').each(function () {
                    var id = $(this).data('id');
                    var f  = fields.find(function(x){ return x.id === id; });
                    if (f) newOrder.push(f);
                });
                fields = newOrder;
                renderPreview();
            }
        }).disableSelection();
    }

    /* ── Add field from palette ─────────────────────────────────────────────── */
    $('.ssb-palette-item[data-type]').on('click', function () {
        var type = $(this).data('type');
        var def  = FIELD_DEFAULTS[type] || {};
        var f = {
            id:          uid(),
            type:        type,
            label:       def.label    || type,
            placeholder: def.placeholder || '',
            required:    false,
            options:     (def.options   || []).slice(),
            width:       def.width    || 'full',
            help_text:   '',
            style:       {}, style_customized:false,
        };
        // type-specific extras
        if (type === 'phone')    { f.enable_country_code = true; }
        if (type === 'date')     { f.disable_past = true; }
        if (type === 'timeslot') { f.timeslot_mode = 'select'; } // 'select' or 'radio'
        fields.push(f);
        renderCanvas();
        selectField(f.id);
    });

    /* ── Templates ──────────────────────────────────────────────────────────── */
    $('.ssb-palette-item[data-template]').on('click', function () {
        var tpl = $(this).data('template');
        var tFields = TEMPLATES[tpl];
        if (!tFields) return;
        if (fields.length && !confirm('This will replace existing fields. Continue?')) return;
        fields = tFields.map(function(f){ return Object.assign({}, f, {id: uid()}); });

        // Set form name if blank
        if (!$('#ssb-form-name').val()) {
            var names = {contact:'Contact Form', lead:'Lead Capture Form', survey:'Customer Survey'};
            $('#ssb-form-name').val(names[tpl] || '');
        }

        // Default settings per template
        if (tpl === 'contact') {
            $('#set-submit-label').val('Send Message');
            $('#set-success-msg').val('Thank you! We\'ll be in touch shortly.');
            settings.submit_label = 'Send Message';
            settings.success_msg  = 'Thank you! We\'ll be in touch shortly.';
        }

    
        activeId = null;
        renderCanvas();
        showFieldInspectorEmpty();
    });

    /* ── Field selection & inspector ────────────────────────────────────────── */
    function selectField(id) {
        activeId = id;
        $('#ssb-drop-zone .ssb-field-block').removeClass('active');
        $('#ssb-drop-zone .ssb-field-block[data-id="' + id + '"]').addClass('active');
        var f = fields.find(function(x){ return x.id === id; });
        if (f) showFieldInspector(f);
    }

    function getField(id) { return fields.find(function(x){ return x.id === id; }); }

    function showFieldInspectorEmpty() {
        $('#ssb-inspector-field').html('<div class="ssb-inspector-empty"><div style="font-size:2rem;margin-bottom:8px;">👈</div>Click a field to edit its properties</div>');
    }

    function showFieldInspector(f) {
        var hasOptions = ['select','radio','checkbox','timeslot'].includes(f.type);
        var isDecor    = ['heading','divider'].includes(f.type);

        var html = '<div style="font-size:.75rem;font-weight:700;color:#667eea;text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px;">' +
                   ICONS[f.type] + ' ' + f.type.charAt(0).toUpperCase()+f.type.slice(1) + ' Field</div>';

        if (!isDecor) {
            html += inspField('Label', '<input class="ssb-inspector-input" id="fi-label" value="' + esc(f.label) + '">');
            if (f.type !== 'timeslot' && f.type !== 'timezone') {
                html += inspField('Placeholder', '<input class="ssb-inspector-input" id="fi-ph" value="' + esc(f.placeholder) + '">');
            }
            html += inspField('Help text', '<input class="ssb-inspector-input" id="fi-help" value="' + esc(f.help_text||'') + '" placeholder="Small hint below the field">');
            html += inspField('Required',
                '<label class="ssb-inspector-toggle"><input type="checkbox" id="fi-req"' + (f.required ? ' checked' : '') + '><span style="font-size:.85rem;">This field is required</span></label>');
            html += inspField('Width',
                '<div class="ssb-width-toggle">' +
                '  <div class="ssb-width-btn ' + (f.width==='full'?'active':'') + '" data-w="full">Full</div>' +
                '  <div class="ssb-width-btn ' + (f.width==='half'?'active':'') + '" data-w="half">Half</div>' +
                '</div>');
            var fs = f.style || {};
            html += '<div class="ssb-inspector-section-title">Selected Field Appearance</div>';
            html += '<label class="ssb-inspector-toggle" style="margin-bottom:10px;"><input type="checkbox" id="fi-inherit-style"' + (!f.style_customized ? ' checked' : '') + '><span style="font-size:.85rem;">Inherit form-level input styling</span></label>';
            html += '<div class="ssb-style-grid">' +
                '<div><label class="ssb-inspector-label">Background</label><input type="color" class="ssb-style-color" id="fi-style-bg" value="' + (fs.bg||'#f9fafb') + '"></div>' +
                '<div><label class="ssb-inspector-label">Text color</label><input type="color" class="ssb-style-color" id="fi-style-text" value="' + (fs.text||'#111827') + '"></div>' +
                '<div><label class="ssb-inspector-label">Border color</label><input type="color" class="ssb-style-color" id="fi-style-border" value="' + (fs.border||'#e5e7eb') + '"></div>' +
                '<div><label class="ssb-inspector-label">Border width</label><input class="ssb-inspector-input" type="number" id="fi-style-border-width" min="0" max="6" value="' + (fs.border_width!==undefined?fs.border_width:1) + '"></div>' +
                '<div><label class="ssb-inspector-label">Radius</label><input class="ssb-inspector-input" type="number" id="fi-style-radius" min="0" max="60" value="' + (fs.radius||12) + '"></div>' +
                '<div><label class="ssb-inspector-label">Font size</label><input class="ssb-inspector-input" type="number" id="fi-style-font-size" min="10" max="30" value="' + (fs.font_size||15) + '"></div>' +
                '<div><label class="ssb-inspector-label">Padding</label><input class="ssb-inspector-input" type="number" id="fi-style-padding" min="4" max="40" value="' + (fs.padding||14) + '"></div>' +
                '</div>';

            // Phone-specific
            if (f.type === 'phone') {
                html += inspField('Country Code Picker',
                    '<label class="ssb-inspector-toggle"><input type="checkbox" id="fi-cc"' + (f.enable_country_code ? ' checked' : '') + '><span style="font-size:.85rem;">Show country code dropdown</span></label>');
            }

            // Date-specific
            if (f.type === 'date') {
                html += inspField('Past Dates',
                    '<label class="ssb-inspector-toggle"><input type="checkbox" id="fi-disablepast"' + (f.disable_past !== false ? ' checked' : '') + '><span style="font-size:.85rem;">Disable past dates</span></label>');
            }

            // Timeslot-specific
            if (f.type === 'timeslot') {
                html += inspField('Display Style',
                    '<select class="ssb-inspector-input" id="fi-ts-mode">' +
                    '<option value="select"' + (f.timeslot_mode==='select'?' selected':'') + '>Dropdown</option>' +
                    '<option value="radio"' + (f.timeslot_mode==='radio'?' selected':'') + '>Radio Buttons</option>' +
                    '</select>');
            }
        } else {
            html += inspField('Label / Text', '<input class="ssb-inspector-input" id="fi-label" value="' + esc(f.label) + '">');
        }

        if (hasOptions) {
            var optLabel = f.type === 'timeslot' ? 'Time Slots' : 'Options';
            html += '<div class="ssb-inspector-field"><label class="ssb-inspector-label">' + optLabel + '</label>';
            html += '<div class="ssb-options-list" id="fi-options-list">';
            (f.options || []).forEach(function(opt, i){
                html += '<div class="ssb-option-row">' +
                        '<input class="fi-option" data-idx="' + i + '" value="' + esc(opt) + '">' +
                        '<button class="ssb-option-del" data-idx="' + i + '">✕</button>' +
                        '</div>';
            });
            html += '</div>';
            var addLabel = f.type === 'timeslot' ? '+ Add time slot' : '+ Add option';
            html += '<button class="ssb-add-option">' + addLabel + '</button>';
            if (f.type === 'select') {
                html += '<div class="ssb-csv-import">' +
                    '<label class="ssb-inspector-label">Import options from CSV</label>' +
                    '<input type="file" id="fi-csv" accept=".csv,text/csv">' +
                    '<small>CSV format: one option per row in the first column. A header row is optional. Uploading replaces the current options.</small>' +
                    '<button type="button" class="button" id="fi-csv-upload" style="margin-top:7px;">Upload CSV</button>' +
                    '<span id="fi-csv-status" style="display:block;margin-top:5px;font-size:.72rem;"></span>' +
                    '</div>';
            }
            html += '</div>';
        }

        $('#ssb-inspector-field').html(html);

        // Live bindings
        $('#fi-label').on('input', function(){ update(f.id,'label',this.value); });
        $('#fi-ph').on('input',    function(){ update(f.id,'placeholder',this.value); });
        $('#fi-help').on('input',  function(){ update(f.id,'help_text',this.value); });
        $('#fi-req').on('change',  function(){ update(f.id,'required',this.checked); });
        $('#fi-cc').on('change',   function(){ update(f.id,'enable_country_code',this.checked); });
        $('#fi-disablepast').on('change', function(){ update(f.id,'disable_past',this.checked); });
        $('#fi-ts-mode').on('change', function(){ update(f.id,'timeslot_mode',this.value); renderPreview(); });
        $('#fi-inherit-style').on('change', function(){ var fld=getField(f.id); if(!fld) return; fld.style_customized=!this.checked; renderPreview(); });
        $('#ssb-inspector-field').off('input.ssbFieldStyle change.ssbFieldStyle')
            .on('input.ssbFieldStyle change.ssbFieldStyle', '[id^="fi-style-"]', function(){
                var fld=getField(f.id); if(!fld) return;
                fld.style=fld.style||{};
                fld.style_customized=true;
                var map={'fi-style-bg':'bg','fi-style-text':'text','fi-style-border':'border','fi-style-border-width':'border_width','fi-style-radius':'radius','fi-style-font-size':'font_size','fi-style-padding':'padding'};
                var key=map[this.id]; if(key) fld.style[key]=(this.type==='color'||this.type==='text')?this.value:parseInt(this.value||0,10);
                renderPreview();
            });

        $('#ssb-inspector-field').off('click.ssbWidth').on('click.ssbWidth', '.ssb-width-btn', function(){
            var w = $(this).data('w');
            update(f.id,'width',w);
            $('#ssb-inspector-field .ssb-width-btn').removeClass('active');
            $(this).addClass('active');
        });

        if (hasOptions) {
            $('#ssb-inspector-field').off('input.ssbOption').on('input.ssbOption', '.fi-option', function(){
                var idx = parseInt($(this).data('idx'));
                var fld = getField(f.id);
                if (fld) fld.options[idx] = this.value;
                renderPreview();
            });
            $('#ssb-inspector-field').off('click.ssbOptionDel').on('click.ssbOptionDel', '.ssb-option-del', function(){
                var idx = parseInt($(this).data('idx'));
                var fld = getField(f.id);
                if (fld) { fld.options.splice(idx,1); }
                showFieldInspector(getField(f.id));
                renderPreview();
            });
            $('#ssb-inspector-field').off('click.ssbAddOption').on('click.ssbAddOption', '.ssb-add-option', function(){
                var fld = getField(f.id);
                var newVal = f.type === 'timeslot' ? '10:00 AM' : 'New Option';
                if (fld) fld.options.push(newVal);
                showFieldInspector(getField(f.id));
                renderPreview();
            });
            $('#ssb-inspector-field').off('click.ssbCsv').on('click.ssbCsv', '#fi-csv-upload', function(){
                var input = document.getElementById('fi-csv');
                if (!input || !input.files.length) { $('#fi-csv-status').css('color','#dc2626').text('Choose a CSV file first.'); return; }
                var fd = new FormData();
                fd.append('action','ssb_import_select_csv');
                fd.append('nonce',ssbForms.nonce);
                fd.append('csv_file',input.files[0]);
                $('#fi-csv-upload').prop('disabled',true);
                $('#fi-csv-status').css('color','#64748b').text('Importing…');
                $.ajax({url:ssbForms.ajaxUrl,type:'POST',data:fd,processData:false,contentType:false}).done(function(r){
                    if(r.success){
                        var fld=getField(f.id);
                        if(fld){ fld.options=r.data.options||[]; showFieldInspector(fld); renderPreview(); }
                    } else {
                        $('#fi-csv-status').css('color','#dc2626').text((r.data&&r.data.msg)||'Import failed.');
                    }
                }).fail(function(){ $('#fi-csv-status').css('color','#dc2626').text('Upload failed.'); })
                  .always(function(){ $('#fi-csv-upload').prop('disabled',false); });
            });
        }
    }

    function inspField(labelText, inputHtml) {
        return '<div class="ssb-inspector-field"><label class="ssb-inspector-label">' + labelText + '</label>' + inputHtml + '</div>';
    }

    function update(id, key, value) {
        var f = getField(id);
        if (!f) return;
        f[key] = value;
        // Update block label preview live
        if (key === 'label') {
            $('#ssb-drop-zone .ssb-field-block[data-id="' + id + '"] .ssb-field-label-preview').text(value || 'Untitled');
        }
        if (key === 'required') {
            var dot = $('#ssb-drop-zone .ssb-field-block[data-id="' + id + '"] .ssb-field-required-dot');
            value ? dot.addClass('visible') : dot.removeClass('visible');
        }
        renderPreview();
    }

    function esc(str) { return String(str||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

    /* ── Inspector tabs ─────────────────────────────────────────────────────── */
    $('.ssb-inspector-tab').on('click', function(){
        var tab = $(this).data('tab');
        $('.ssb-inspector-tab').removeClass('active');
        $(this).addClass('active');
        if (tab === 'field') {
            $('#ssb-inspector-field').show();
            $('#ssb-inspector-form').hide();
        } else {
            $('#ssb-inspector-field').hide();
            $('#ssb-inspector-form').show();
        }
    });

    /* ── Form settings live binding ─────────────────────────────────────────── */
    var STYLE_DEFAULTS = {
        form_bg:'#ffffff', form_bg_transparent:false, form_border_enabled:true, form_border:'#edf0f3', form_radius:24, form_padding:40, field_gap:18,
        label_color:'#6b7280', label_size:12, input_bg:'#f9fafb', input_text:'#111827',
        input_border:'#e5e7eb', input_focus_border:'#667eea', input_focus_ring:'#dbeafe', input_error_border:'#dc2626', input_error_bg:'#fef2f2', input_placeholder:'#94a3b8', input_border_width:1, input_radius:12, input_padding:14, input_font_size:15,
        button_bg:'#667eea', button_text:'#ffffff', button_hover_bg:'#4f46e5', button_radius:999,
        button_padding_y:15, button_padding_x:34, button_font_size:15, button_full_width:false
    };
    function readFormSettings() {
        var style = {};
        Object.keys(STYLE_DEFAULTS).forEach(function(k){
            var id = '#style-' + k.replace(/_/g,'-');
            var $el = $(id);
            if ($el.length) style[k] = $el.attr('type') === 'checkbox' ? $el.is(':checked') : $el.val();
        });
        return {
            display_title: $('#set-display-title').val(),
            show_title: $('#set-show-title').is(':checked'),
            show_description: $('#set-show-description').is(':checked'),
            show_labels: $('#set-show-labels').is(':checked'),
            submit_label:  $('#set-submit-label').val(),
            success_msg:   $('#set-success-msg').val(),
            notify_email:  $('#set-notify-email').val(),
            email_subject: $('#set-email-subject').val(),
            send_copy:     $('#set-send-copy').is(':checked'),
            redirect_url:  $('#set-redirect-url').val(),
            primary_color: $('#set-primary-color').val(),
            integrations: {
                stripe: {
                    enabled: $('#set-stripe-enabled').is(':checked'),
                    amount: $('#set-stripe-amount').val(),
                    currency: $('#set-stripe-currency').val(),
                    description: $('#set-stripe-description').val()
                },
                google_calendar: {
                    enabled: $('#set-calendar-enabled').is(':checked'),
                    calendar_id: $('#set-calendar-id').val(),
                    event_label: $('#set-calendar-label').val(),
                    brand_name: $('#set-calendar-brand').val()
                }
            },
            style: style
        };
    }

    /* ── Live preview ───────────────────────────────────────────────────────── */
    function renderPreview() {
        var primary  = $('#set-primary-color').val() || '#667eea';
        var submitLbl = $('#set-submit-label').val() || 'Submit';
        var displayTitle = $('#set-display-title').val() || $('#ssb-form-name').val() || '';
        var showTitle = $('#set-show-title').length ? $('#set-show-title').is(':checked') : true;
        var showDescription = $('#set-show-description').length ? $('#set-show-description').is(':checked') : true;
        var st = readFormSettings().style || {};
        var previewBg = st.form_bg_transparent ? 'transparent' : (st.form_bg||'#fff');
        var html = '<div style="font-family:inherit;background:' + previewBg + ';border:' + (st.form_border_enabled === false ? 'none' : '1px solid ' + (st.form_border||'#edf0f3')) + ';border-radius:' + (st.form_radius||24) + 'px;padding:' + (st.form_padding||40) + 'px;">';
        if (showTitle && displayTitle) html += '<h2 style="font-size:26px;line-height:1.2;font-weight:800;margin:0 0 12px;color:#111827;">' + esc(displayTitle) + '</h2>';
        if (showDescription && $('#ssb-form-desc').val()) html += '<p style="color:#6b7280;margin:0 0 20px;line-height:1.6;">' + esc($('#ssb-form-desc').val()).replace(/\n/g,'<br>') + '</p>';

        var i = 0;
        while (i < fields.length) {
            var f = fields[i];
            if (f.type === 'heading') {
                html += '<div style="font-size:1.1rem;font-weight:700;border-bottom:2px solid ' + primary + ';padding-bottom:4px;margin-bottom:12px;">' + esc(f.label) + '</div>';
                i++; continue;
            }
            if (f.type === 'divider') {
                html += '<hr style="border:none;border-top:1px solid #e5e7eb;margin:12px 0;">';
                i++; continue;
            }

            var isHalf  = f.width === 'half';
            var isHalf2 = isHalf && fields[i+1] && fields[i+1].width === 'half';
            var rowStyle = isHalf2 ? 'display:flex;gap:12px;margin-bottom:14px;' : 'margin-bottom:14px;';

            html += '<div style="' + rowStyle + '">';
            html += previewField(f, primary, isHalf2 ? 'flex:1;' : 'width:100%;');

            if (isHalf2) {
                html += previewField(fields[i+1], primary, 'flex:1;');
                i++;
            }
            html += '</div>';
            i++;
        }

        html += '<button style="padding:' + (st.button_padding_y||15) + 'px ' + (st.button_padding_x||34) + 'px;background:' + (st.button_bg||primary) + ';color:' + (st.button_text||'#fff') + ';border:none;border-radius:' + (st.button_radius||999) + 'px;font-size:' + (st.button_font_size||15) + 'px;font-weight:700;cursor:default;' + (st.button_full_width?'width:100%;':'') + '">' + esc(submitLbl) + '</button>';
        html += '</div>';
        $('#ssb-live-preview').html(html);
    }

    function previewField(f, primary, extraStyle) {
        var formSettings = readFormSettings();
        var st = formSettings.style || {};
        st.show_labels = formSettings.show_labels;
        var fs = f.style_customized ? (f.style || {}) : {};
        var lbl = st.show_labels === false ? '' : '<label style="display:block;font-size:' + (st.label_size||12) + 'px;font-weight:600;margin-bottom:4px;color:' + (st.label_color||'#6b7280') + ';">' + esc(f.label) + (f.required ? '<span style="color:#ef4444;"> *</span>' : '') + '</label>';
        var wrap = '<div style="' + extraStyle + '">' + lbl;
        var inputStyle = 'width:100%;padding:' + (fs.padding||st.input_padding||14) + 'px;border:' + (fs.border_width!==undefined?fs.border_width:(st.input_border_width||1)) + 'px solid ' + (fs.border||st.input_border||'#e5e7eb') + ';border-radius:' + (fs.radius||st.input_radius||12) + 'px;font-size:' + (fs.font_size||st.input_font_size||15) + 'px;color:' + (fs.text||st.input_text||'#111827') + ';box-sizing:border-box;background:' + (fs.bg||st.input_bg||'#f9fafb') + ';';
        var ph = esc(f.placeholder || '');

        switch (f.type) {
            case 'textarea':
                wrap += '<textarea style="' + inputStyle + 'min-height:80px;" readonly placeholder="' + ph + '"></textarea>'; break;
            case 'select':
                wrap += '<select style="' + inputStyle + '" disabled><option>' + esc(f.placeholder || 'Choose…') + '</option>' +
                        (f.options||[]).map(function(o){ return '<option>' + esc(o) + '</option>'; }).join('') + '</select>'; break;
            case 'radio':
                wrap += '<div>' + (f.options||[]).map(function(o){
                    return '<label style="display:flex;align-items:center;gap:6px;margin-bottom:4px;font-size:.85rem;"><input type="radio" disabled> ' + esc(o) + '</label>';
                }).join('') + '</div>'; break;
            case 'checkbox':
                wrap += '<div>' + (f.options||[]).map(function(o){
                    return '<label style="display:flex;align-items:center;gap:6px;margin-bottom:4px;font-size:.85rem;"><input type="checkbox" disabled> ' + esc(o) + '</label>';
                }).join('') + '</div>'; break;
            case 'date':
                wrap += '<input type="date" style="' + inputStyle + '" readonly>'; break;
            case 'phone':
                if (f.enable_country_code) {
                    wrap += '<div style="display:flex;gap:6px;">' +
                            '<select style="width:130px;padding:8px 6px;border:2px solid #e5e7eb;border-radius:8px;font-size:.8rem;background:#f9fafb;" disabled><option>🇺🇸 +1</option><option>🇬🇧 +44</option><option>🇩🇪 +49</option></select>' +
                            '<input type="tel" style="flex:1;padding:8px 10px;border:2px solid #e5e7eb;border-radius:8px;font-size:.85rem;background:#f9fafb;" placeholder="Phone number" readonly>' +
                            '</div>';
                } else {
                    wrap += '<input type="tel" style="' + inputStyle + '" placeholder="+1 234 567 8900" readonly>';
                }
                break;
            case 'timeslot':
                if (f.timeslot_mode === 'radio') {
                    wrap += '<div style="display:flex;flex-wrap:wrap;gap:8px;">' + (f.options||[]).map(function(o){
                        return '<label style="display:flex;align-items:center;gap:5px;padding:6px 12px;border:2px solid #e5e7eb;border-radius:8px;font-size:.82rem;background:#f9fafb;cursor:not-allowed;">' +
                               '<input type="radio" disabled> ' + esc(o) + '</label>';
                    }).join('') + '</div>';
                } else {
                    wrap += '<select style="' + inputStyle + '" disabled>' +
                            '<option>Select a time slot…</option>' +
                            (f.options||[]).map(function(o){ return '<option>' + esc(o) + '</option>'; }).join('') +
                            '</select>';
                }
                break;
            case 'timezone':
                wrap += '<select style="' + inputStyle + '" disabled>' +
                        '<option>Select your timezone…</option>' +
                        '<option>UTC-12:00 — Baker Island</option>' +
                        '<option>UTC-08:00 — Pacific Time (US)</option>' +
                        '<option>UTC+00:00 — London / UTC</option>' +
                        '<option>UTC+05:30 — India Standard Time</option>' +
                        '<option>UTC+08:00 — China / Singapore</option>' +
                        '</select>';
                break;
            default:
                wrap += '<input type="' + f.type + '" style="' + inputStyle + '" placeholder="' + ph + '" readonly>';
        }
        if (f.help_text) wrap += '<p style="font-size:.7rem;color:#9ca3af;margin:3px 0 0;">' + esc(f.help_text) + '</p>';
        return wrap + '</div>';
    }

    /* ── Count update ───────────────────────────────────────────────────────── */
    function updateCount() {
        $('#ssb-field-count').text(fields.filter(function(f){ return f.type !== 'divider'; }).length);
    }

    /* ── Save ───────────────────────────────────────────────────────────────── */
    $('#ssb-save-form').on('click', function(){
        var name = $('#ssb-form-name').val().trim();
        if (!name) { builderToast('Please enter a form name.', 'error'); $('#ssb-form-name').focus(); return; }
        if (!fields.length) { builderToast('Please add at least one field.', 'error'); return; }

        var $btn = $(this);
        $btn.prop('disabled', true).text('Saving…');
        $('#ssb-save-status').text('');

        var payload = {
            action:      'ssb_save_form',
            nonce:       ssbForms.nonce,
            form_id:     $('#ssb-form-id').val() || 0,
            form_name:   name,
            description: $('#ssb-form-desc').val(),
            fields:      JSON.stringify(fields),
            settings:    JSON.stringify(readFormSettings()),
        };

        $.post(ssbForms.ajaxUrl, payload, function(r){
            $btn.prop('disabled', false).text('Save Form');
            if (r.success) {
                var newId = r.data.form_id;
                $('#ssb-form-id').val(newId);
                $('#ssb-save-status').css('color','#10b981').text('Saved');
                builderToast('Form saved successfully.', 'success');
                // Update shortcode display
                $('.ssb-save-bar-info strong:last').text('[ssb_form id="' + newId + '"]');

                setTimeout(function(){
                    if (!window.location.href.includes('form_id=')) {
                        history.replaceState(null,'','?page=ssb-forms&ssb_action=edit&form_id=' + newId);
                    }
                    $('#ssb-save-status').text('');
                }, 3000);
            } else {
                $('#ssb-save-status').css('color','#ef4444').text('Save failed');
                builderToast((r.data && r.data.msg) || 'Save failed.', 'error');
            }
        }).fail(function(){
            $btn.prop('disabled', false).text('Save Form');
            $('#ssb-save-status').css('color','#ef4444').text('Network error');
            builderToast('Network error while saving the form.', 'error');
        });
    });

    /* ── Form settings live preview binding ─────────────────────────────────── */
    $('#set-submit-label, #set-primary-color, #set-display-title, #set-show-title, #set-show-description, #set-show-labels, #ssb-form-name, #ssb-form-desc').on('input change', function(){ renderPreview(); });

    /* ── Keyboard shortcut ──────────────────────────────────────────────────── */
    $(document).on('keydown', function(e){
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            $('#ssb-save-form').trigger('click');
        }
    });

    /* ── Canvas drag-over highlight ─────────────────────────────────────────── */
    $('#ssb-drop-zone').on('sortover', function(){ $(this).addClass('drag-over'); })
                       .on('sortout',  function(){ $(this).removeClass('drag-over'); });

    /* ── Initialise ─────────────────────────────────────────────────────────── */
    // Seed settings inputs from stored data
    if (settings.notify_email)  $('#set-notify-email').val(settings.notify_email);
    if (settings.email_subject) $('#set-email-subject').val(settings.email_subject);
    if (settings.display_title !== undefined) $('#set-display-title').val(settings.display_title);
    $('#set-show-title').prop('checked', settings.show_title !== false);
    $('#set-show-description').prop('checked', settings.show_description !== false);
    $('#set-show-labels').prop('checked', settings.show_labels !== false);
    if (settings.primary_color) $('#set-primary-color').val(settings.primary_color);
    if (settings.redirect_url)  $('#set-redirect-url').val(settings.redirect_url);
    if (settings.send_copy)     $('#set-send-copy').prop('checked', true);

    // Restore per-form integration and style settings.
    var integ = settings.integrations || {};
    var stripe = integ.stripe || {}, cal = integ.google_calendar || {};
    $('#set-stripe-enabled').prop('checked', !!stripe.enabled);
    $('#set-stripe-amount').val(stripe.amount || 0);
    $('#set-stripe-currency').val(stripe.currency || 'USD');
    $('#set-stripe-description').val(stripe.description || '');
    $('#set-calendar-enabled').prop('checked', !!cal.enabled);
    $('#set-calendar-id').val(cal.calendar_id || 'primary');
    $('#set-calendar-label').val(cal.event_label || '');
    $('#set-calendar-brand').val(cal.brand_name || '');
    function toggleIntegrationPanels(){
        $('#ssb-stripe-settings').toggle($('#set-stripe-enabled').is(':checked'));
        $('#ssb-calendar-settings').toggle($('#set-calendar-enabled').is(':checked'));
    }
    $('#set-stripe-enabled,#set-calendar-enabled').on('change', toggleIntegrationPanels);
    toggleIntegrationPanels();

    var savedStyle = settings.style || {};
    Object.keys(STYLE_DEFAULTS).forEach(function(k){
        var id = '#style-' + k.replace(/_/g,'-');
        var $el=$(id);
        if($el.length){
            var val = savedStyle[k] !== undefined ? savedStyle[k] : STYLE_DEFAULTS[k];
            if($el.attr('type') === 'checkbox') $el.prop('checked', !!val); else $el.val(val);
        }
    });
    $('.ssb-inspector-body').on('input change','[id^="style-"]',function(){ renderPreview(); });
    // Hex is the primary color input; native picker is a secondary convenience.
    $('.ssb-color-control').each(function(){
        var $wrap=$(this), $hex=$wrap.find('.ssb-color-hex'), $picker=$wrap.find('.ssb-color-picker');
        function validHex(v){ return /^#[0-9a-fA-F]{6}$/.test(v); }
        $hex.on('input change', function(){ var v=this.value.trim(); if(validHex(v)) $picker.val(v); renderPreview(); });
        $picker.on('input change', function(){ $hex.val(this.value.toLowerCase()); renderPreview(); });
    });


    $(document).on('input change', '.ssb-color-picker', function(){
        var target=$(this).data('color-for');
        if(target) $('#'+target).val(this.value.toLowerCase()).trigger('input');
    });
    $(document).on('input change', '.ssb-color-hex', function(){
        var v=this.value.trim();
        if(/^#[0-9a-fA-F]{6}$/.test(v)){ var picker=$('.ssb-color-picker[data-color-for="'+this.id+'"]'); if(picker.length) picker.val(v); }
    });

    renderCanvas();
    if (fields.length) selectField(fields[0].id);
});
