<?php
if ( ! defined('ABSPATH') ) exit;

/**
 * Public verification key for FormPilot commercial entitlements.
 * The private signing key exists only on the licensing server.
 */
define('SSB_LICENSE_PUBLIC_KEY', <<<'FORMPILOT_PUBLIC_KEY'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA1CbDf+CHsnqFQ3sCLhd3
D4CdgfHNdHYQZxaNZjFOBsLM17DR41csm0OstwZEyuAg6y2kAUDV1XP/FIgF2ICE
l9VvDJ28KT9xqzBfeuDNVGQBed+/5nhLKz+0Csoig/E+tsEPBBZmjjg3KEAlgeeV
Bb5wkU8BedEABndisuiBmdptQhE7m/T6kXEb1XLsqKqrvzviM1MaDA4JuWE1PAli
IpxLii8RjpjbB+GVgQR81ytWE6MOGxf5VGxfqUqG1z6n2B9BFAMDdtcneYkjr14g
pfRlosBFjpBfhOFQLNDBOx4ODI6/ug9CeV/Jzq1k2+egE+nqiTDubEzfeAlUlSPS
y0xgzNfEwNkSfKuIsHjJvyes36h8OMleUTXrAREmdsiM7qw5Q/FnuMH5b6qJt8J8
JakTNLacFbhEWgxLC4UkEhxoiqBKqEhH2CNVqsde6qYx2uQva8PEOqs+Q03RVYnn
1gRN57fLT5ULVyKaT+cBNc/oOzAhc0tF6scxjbtEr6VRAgMBAAE=
-----END PUBLIC KEY-----
FORMPILOT_PUBLIC_KEY
);

/**
 * FormPilot Pro commercial licensing client.
 * The license server decides which domains/features are authorized.
 */
function ssb_license_server_url() {
    // Commercial builds are pinned to the official FormPilot licensing server.
    if (defined('SSB_LICENSE_SERVER_URL') && SSB_LICENSE_SERVER_URL) return untrailingslashit(esc_url_raw(SSB_LICENSE_SERVER_URL));
    return '';
}
function ssb_license_key() { return trim((string)get_option('ssb_license_key','')); }
function ssb_license_payload() { $v = get_option('ssb_license_payload', []); return is_array($v) ? $v : []; }
function ssb_license_last_check() { return (int)get_option('ssb_license_last_check', 0); }
function ssb_license_grace_until() { return (int)get_option('ssb_license_grace_until', 0); }
function ssb_license_message() { return sanitize_text_field(get_option('ssb_license_message','')); }

function ssb_license_domain() {
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    $host = strtolower((string)$host);
    return preg_replace('/^www\./', '', $host);
}
function ssb_license_endpoint($path) {
    $base = trailingslashit(ssb_license_server_url());
    if (!$base) return '';
    return $base . 'wp-json/formpilot/v1/license/' . ltrim($path,'/');
}
function ssb_license_request($action) {
    $key = ssb_license_key();
    if (!ssb_license_server_url() || !$key) return new WP_Error('license_not_configured','License server URL and license key are required.');

    $payload = [
        'license_key'=>$key,
        'site_url'=>home_url('/'),
        'plugin_version'=>SSB_VERSION,
        'wp_version'=>get_bloginfo('version'),
    ];

    // Try the normal REST URL first, then WordPress' rest_route fallback.
    // The fallback is useful on hosts where /wp-json/ is blocked or rewrite rules are not ready yet.
    $endpoints = [
        ssb_license_endpoint($action),
        add_query_arg('rest_route', '/formpilot/v1/license/' . ltrim($action,'/'), trailingslashit(ssb_license_server_url())),
    ];
    $last_error = null;

    foreach (array_unique(array_filter($endpoints)) as $endpoint) {
        $response = wp_remote_post($endpoint, [
            'timeout' => 20,
            'redirection' => 3,
            'sslverify' => true,
            'headers' => ['Accept'=>'application/json','Content-Type'=>'application/json'],
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($response)) {
            $last_error = $response;
            continue;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!is_array($data)) {
            $ctype = (string) wp_remote_retrieve_header($response, 'content-type');
            $preview = trim(wp_strip_all_tags($body));
            if (strlen($preview) > 180) $preview = substr($preview, 0, 180) . '…';
            $message = 'License server did not return JSON (HTTP ' . ($code ?: 0) . ').';
            if ($ctype) $message .= ' Content-Type: ' . sanitize_text_field($ctype) . '.';
            if ($preview) $message .= ' Response: ' . sanitize_text_field($preview);
            $last_error = new WP_Error('license_invalid_response', $message, ['status'=>$code,'endpoint'=>$endpoint]);
            continue;
        }

        if ($code < 200 || $code >= 300 || empty($data['valid'])) {
            return new WP_Error('license_rejected', sanitize_text_field($data['message'] ?? 'License validation failed.'), ['response'=>$data,'status'=>$code]);
        }
        return $data;
    }

    return $last_error ?: new WP_Error('license_unreachable','The FormPilot license server could not be reached.');
}
function ssb_license_verify_signature($data) {
    if (!is_array($data) || empty($data['license']) || empty($data['signature'])) return false;
    $entitlement=$data['license'];
    if (($entitlement['product'] ?? '') !== 'formpilot-pro') return false;
    $json=wp_json_encode($entitlement,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    $sig=base64_decode((string)$data['signature'],true);
    if (!$sig || !function_exists('openssl_verify')) return false;
    return 1 === openssl_verify($json,$sig,SSB_LICENSE_PUBLIC_KEY,OPENSSL_ALGO_SHA256);
}
function ssb_license_store_valid($data) {
    if (!ssb_license_verify_signature($data) || (($data['license']['domain'] ?? '') !== ssb_license_domain())) {
        update_option('ssb_license_message','The license server returned an invalid signed entitlement.',false);
        return false;
    }
    update_option('ssb_license_signature', sanitize_text_field((string)$data['signature']), false);
    update_option('ssb_license_payload', is_array($data['license'] ?? null) ? $data['license'] : [], false);
    update_option('ssb_license_last_check', time(), false);
    update_option('ssb_license_grace_until', time() + 7 * DAY_IN_SECONDS, false);
    update_option('ssb_license_message', 'License active.', false);
}
function ssb_license_validate($force=false) {
    if (!ssb_license_key() || !ssb_license_server_url()) return false;
    if (!$force && ssb_license_last_check() && (time() - ssb_license_last_check()) < DAY_IN_SECONDS) {
        $payload = ssb_license_payload();
        return ssb_license_verify_signature(['license'=>$payload,'signature'=>get_option('ssb_license_signature','')]) && !empty($payload['status']) && $payload['status'] === 'active';
    }
    $data = ssb_license_request('validate');
    if (is_wp_error($data)) {
        update_option('ssb_license_message', $data->get_error_message(), false);
        $details = $data->get_error_data();
        $remote = is_array($details) && is_array($details['response'] ?? null) ? $details['response'] : [];
        // A signed server decision such as suspended/revoked/expired is authoritative and must never use offline grace.
        if (!empty($remote['license']) && !empty($remote['signature']) && ssb_license_verify_signature($remote)) {
            $status = sanitize_key($remote['license']['status'] ?? '');
            if (in_array($status, ['suspended','revoked','expired'], true)) {
                update_option('ssb_license_signature', sanitize_text_field((string)$remote['signature']), false);
                update_option('ssb_license_payload', is_array($remote['license']) ? $remote['license'] : [], false);
                update_option('ssb_license_last_check', time(), false);
                delete_option('ssb_license_grace_until');
                return false;
            }
        }
        return ssb_license_grace_until() > time();
    }
    if (!ssb_license_store_valid($data)) return false;
    return true;
}
function ssb_license_activate($server_url, $key) {
    // Ignore client-supplied license server URLs in commercial builds.
    $key = preg_replace('/\s+/', '', strtoupper(sanitize_text_field($key)));
    update_option('ssb_license_key', $key, false);
    delete_option('ssb_license_payload');
    delete_option('ssb_license_signature');
    delete_option('ssb_license_last_check');
    delete_option('ssb_license_grace_until');
    $data = ssb_license_request('activate');
    if (is_wp_error($data)) {
        update_option('ssb_license_message', $data->get_error_message(), false);
        return $data;
    }
    if (!ssb_license_store_valid($data)) return new WP_Error('license_invalid_signature','The license server returned an invalid signed entitlement.');
    return $data;
}
function ssb_license_deactivate() {
    $data = ssb_license_request('deactivate');
    delete_option('ssb_license_payload');
    delete_option('ssb_license_signature');
    delete_option('ssb_license_last_check');
    delete_option('ssb_license_grace_until');
    update_option('ssb_license_message', is_wp_error($data) ? $data->get_error_message() : 'License deactivated.', false);
    return $data;
}
function ssb_license_status() {
    $payload = ssb_license_payload();
    $signature = get_option('ssb_license_signature','');
    $signature_ok = ssb_license_verify_signature(['license'=>$payload,'signature'=>$signature]);
    $active = $signature_ok && (($payload['domain'] ?? '') === ssb_license_domain()) && !empty($payload['status']) && $payload['status'] === 'active';
    if ($active && !empty($payload['expires_at']) && strtotime($payload['expires_at']) < current_time('timestamp')) { $active = false; }
    $authoritative_inactive = in_array(sanitize_key($payload['status'] ?? ''), ['suspended','revoked','expired'], true);
    $grace = !$active && !$authoritative_inactive && ssb_license_grace_until() > time();
    return [
        'active'=>$active || $grace,
        'server_active'=>$active,
        'grace'=>$grace,
        'plan'=>sanitize_key($payload['plan'] ?? ''),
        'expires_at'=>sanitize_text_field($payload['expires_at'] ?? ''),
        'features'=>is_array($payload['features'] ?? null) ? $payload['features'] : (['core'=>true,'forms'=>true,'builder'=>true]),
        'domain'=>sanitize_text_field($payload['domain'] ?? ''),
        'message'=>ssb_license_message(),
    ];
}
function ssb_license_can($feature='core') {
    $state = ssb_license_status();
    // FormPilot has a genuine free tier. Core administration, the form builder, and basic forms remain available without a license.
    if (!$state['active']) return in_array($feature, ['core','forms','builder'], true);
    if (!$feature) return true;
    if (!$state['features']) return false;
    // Paid FormPilot plans are full-feature plans. Older signed entitlements
    // may predate a feature key added in a later client release; keep those
    // valid paid licenses functional while the signed plan remains active.
    if (!array_key_exists($feature, $state['features'])) {
        $full_plans = ['premium','agency','lifetime'];
        if (in_array(sanitize_key($state['plan'] ?? ''), $full_plans, true)) return true;
    }
    return !empty($state['features'][$feature]);
}
function ssb_license_admin_guard($feature='core') {
    if (ssb_license_can($feature)) return true;
    echo '<div class="wrap"><div class="notice notice-error"><p><strong>FormPilot Pro license required.</strong> Activate a valid license for this website to use this feature.</p><p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=ssb-license')) . '">Activate License</a></p></div></div>';
    return false;
}
function ssb_license_cron() { ssb_license_validate(true); }
function ssb_license_schedule() {
    if (!wp_next_scheduled('ssb_license_daily_check')) wp_schedule_event(time()+300, 'daily', 'ssb_license_daily_check');
}
add_action('ssb_license_daily_check','ssb_license_cron');
function ssb_license_unschedule() { $t=wp_next_scheduled('ssb_license_daily_check'); if($t) wp_unschedule_event($t,'ssb_license_daily_check'); }

function ssb_license_page() {
    if (!current_user_can('manage_options')) return;
    $notice=''; $type='';
    if (isset($_POST['ssb_license_action']) && check_admin_referer('ssb_license_settings')) {
        $action=sanitize_key($_POST['ssb_license_action']);
        if($action==='activate'){
            $result=ssb_license_activate($_POST['ssb_license_server_url']??'',$_POST['ssb_license_key']??'');
            if(is_wp_error($result)){ $notice=$result->get_error_message(); $type='error'; } else { $notice='License activated for '.ssb_license_domain().'.'; $type='success'; }
        } elseif($action==='deactivate'){
            $result=ssb_license_deactivate(); $notice=is_wp_error($result)?$result->get_error_message():'License deactivated.'; $type=is_wp_error($result)?'error':'success';
        } elseif($action==='check'){
            $ok=ssb_license_validate(true); $notice=ssb_license_message(); $type=$ok?'success':'error';
        }
    }
    $state=ssb_license_status();
    ?>
    <div class="wrap ssb-license-page"><div class="ssb-license-hero"><div><span>FormPilot Pro</span><h1>Commercial License</h1><p>Authorize this WordPress installation and unlock the features included in its plan.</p></div><div class="ssb-license-status <?php echo $state['active']?'active':'inactive'; ?>"><?php echo $state['active']?'● Active':'● Not active'; ?></div></div>
    <?php if($notice): ?><div class="notice notice-<?php echo esc_attr($type); ?> is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
    <div class="ssb-license-grid"><div class="ssb-license-card"><h2>License Connection</h2><form method="post"><?php wp_nonce_field('ssb_license_settings'); ?><input type="hidden" name="ssb_license_action" value="activate"><p><label>License Server URL<br><input class="regular-text" type="url" value="<?php echo esc_attr(ssb_license_server_url()); ?>" readonly></label></p><p><label>License Key<br><input class="regular-text" type="text" name="ssb_license_key" value="<?php echo esc_attr(ssb_license_key()); ?>" placeholder="FP-XXXX-XXXX-XXXX-XXXX-XXXX"></label></p><p><label>This website<br><input class="regular-text" readonly value="<?php echo esc_attr(home_url('/')); ?>"></label></p><p><button class="button button-primary">Activate / Update License</button></p><p class="description">This commercial build is securely connected to the official FormPilot license server.</p></form><hr><form method="post" style="display:inline-block"><?php wp_nonce_field('ssb_license_settings'); ?><input type="hidden" name="ssb_license_action" value="check"><button class="button">Check License Now</button></form> <?php if(ssb_license_key()): ?><form method="post" style="display:inline-block;margin-left:8px" onsubmit="return confirm('Deactivate this site license?');"><?php wp_nonce_field('ssb_license_settings'); ?><input type="hidden" name="ssb_license_action" value="deactivate"><button class="button">Deactivate</button></form><?php endif; ?></div>
    <div class="ssb-license-card"><h2>License Details</h2><dl><dt>Domain</dt><dd><?php echo esc_html($state['domain']?:ssb_license_domain()); ?></dd><dt>Plan</dt><dd><?php echo esc_html($state['plan']?:'—'); ?></dd><dt>Expires</dt><dd><?php echo esc_html($state['expires_at']?:'Never'); ?></dd><dt>Last check</dt><dd><?php echo ssb_license_last_check()?esc_html(wp_date(get_option('date_format').' '.get_option('time_format'),ssb_license_last_check())):'—'; ?></dd></dl><h3>Enabled Features</h3><div class="ssb-license-features"><?php foreach($state['features'] as $feature=>$enabled): if($enabled): ?><span><?php echo esc_html(ucwords(str_replace('_',' ',$feature))); ?></span><?php endif; endforeach; ?></div><?php if($state['grace']&&!$state['server_active']): ?><p class="description">The license server could not be reached. FormPilot is using its temporary 7-day grace period.</p><?php endif; ?></div></div></div>
    <style>.ssb-license-page{max-width:1050px;margin-top:22px}.ssb-license-hero{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:28px 30px;border-radius:18px;background:linear-gradient(135deg,#111827,#312e81);color:#fff;margin-bottom:18px}.ssb-license-hero span{font-size:11px;text-transform:uppercase;letter-spacing:.12em;opacity:.7}.ssb-license-hero h1{color:#fff;margin:4px 0;font-size:28px}.ssb-license-hero p{color:#cbd5e1;margin:0}.ssb-license-status{padding:9px 14px;border-radius:999px;font-weight:700;font-size:12px}.ssb-license-status.active{background:#064e3b;color:#a7f3d0}.ssb-license-status.inactive{background:#7f1d1d;color:#fecaca}.ssb-license-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.ssb-license-card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:22px}.ssb-license-card h2{margin-top:0}.ssb-license-card input{margin-top:5px}.ssb-license-card dt{font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;margin-top:12px}.ssb-license-card dd{margin:4px 0 0;font-weight:600}.ssb-license-features{display:flex;flex-wrap:wrap;gap:7px}.ssb-license-features span{background:#eef2ff;color:#4338ca;padding:6px 9px;border-radius:999px;font-size:11px;font-weight:700}@media(max-width:800px){.ssb-license-grid{grid-template-columns:1fr}.ssb-license-hero{align-items:flex-start;flex-direction:column}}</style>
    <?php
}
