<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Form Builder is registered centrally beneath FormPilot Pro.

// ── Admin assets ───────────────────────────────────────────────────────────
add_action( 'admin_enqueue_scripts', 'ssb_forms_admin_assets' );
function ssb_forms_admin_assets( $hook ) {
    if ( strpos($hook, 'ssb-') === false ) return;
    wp_enqueue_script( 'jquery-ui-sortable' );
    wp_enqueue_script( 'ssb-forms-admin', SSB_PLUGIN_URL . 'assets/js/forms-admin.js', ['jquery','jquery-ui-sortable'], SSB_VERSION, true );
    wp_localize_script( 'ssb-forms-admin', 'ssbForms', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('ssb_forms_nonce'),
        'siteUrl' => get_site_url(),
    ]);
    // Plus Jakarta Sans font
    wp_enqueue_style( 'ssb-jakarta-font', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap', [], null );
    wp_add_inline_style( 'ssb-jakarta-font', ssb_forms_admin_css() );
}

function ssb_forms_admin_css() { return '

    .ssb-inspector-section-title{margin:22px 0 10px;padding-top:12px;border-top:1px solid #eef2f7;font-size:.72rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#667eea;}
    .ssb-integration-panel{margin:10px 0 4px;padding:10px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;display:none;}
    .ssb-integration-panel .ssb-inspector-label{margin-top:8px;}
    .ssb-inspector-note{font-size:.72rem;color:#6b7280;line-height:1.5;margin:7px 0 0;}
    .ssb-style-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
    .ssb-style-grid>div{min-width:0;}
    .ssb-style-color{width:42px;height:38px;padding:3px;border:1px solid #e5e7eb;border-radius:6px;background:#fff;} .ssb-color-control{display:flex;gap:6px;align-items:center}.ssb-color-control .ssb-color-hex{flex:1;min-width:0}.ssb-color-picker{flex:0 0 42px}
    .ssb-csv-import{margin-top:8px;padding:10px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;}
    .ssb-csv-import small{display:block;color:#64748b;margin-top:5px;line-height:1.4;}
    .ssb-fb-wrap, .ssb-builder, .ssb-builder * { font-family: "Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, sans-serif !important; }
    #ssb-builder-toast{display:none;position:fixed;right:28px;bottom:78px;z-index:99999;min-width:260px;max-width:420px;padding:12px 16px;border-radius:12px;color:#fff;font-size:13px;font-weight:700;box-shadow:0 16px 40px rgba(15,23,42,.22)}#ssb-builder-toast.success{background:#059669}#ssb-builder-toast.error{background:#dc2626}.ssb-payment-link-note a{color:#4f46e5;font-weight:700;text-decoration:none}.ssb-payment-link-note a:hover{text-decoration:underline}
    .ssb-fb-wrap { max-width:none; margin-right:20px; }
    .ssb-form-cards { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:20px; margin-top:20px; }
    .ssb-form-card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,.05); transition:box-shadow .2s; }
    .ssb-form-card:hover { box-shadow:0 4px 16px rgba(0,0,0,.1); }
    .ssb-form-card-title { font-size:1.1rem; font-weight:700; color:#1f2937; margin:0 0 6px; }
    .ssb-form-card-meta { font-size:.8rem; color:#6b7280; margin-bottom:12px; }
    .ssb-form-card-sc { background:#f3f4f6; border-radius:6px; padding:6px 10px; font-family:monospace; font-size:.85rem; color:#374151; margin-bottom:14px; cursor:copy; border:1px dashed #d1d5db; }
    .ssb-form-card-sc:hover { background:#e5e7eb; }
    .ssb-form-card-actions { display:flex; gap:8px; flex-wrap:wrap; }

    /* Builder layout */
    .ssb-builder { display:grid; grid-template-columns:210px minmax(460px,1fr) 390px; gap:0; height:calc(100vh - 100px); min-height:600px; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; background:#fff; margin-top:16px; }
    .ssb-builder-palette { background:#1f2937; padding:16px; overflow-y:auto; }
    .ssb-builder-palette h3 { color:#9ca3af; font-size:.7rem; text-transform:uppercase; letter-spacing:1px; margin:0 0 10px; }
    .ssb-palette-item { background:#374151; border:1px solid #4b5563; color:#f9fafb; padding:10px 14px; border-radius:8px; margin-bottom:8px; cursor:grab; display:flex; align-items:center; gap:10px; font-size:.875rem; font-weight:600; transition:all .15s; user-select:none; }
    .ssb-palette-item:hover { background:#4b5563; border-color:#667eea; }
    .ssb-palette-item .pi { font-size:1.1rem; }

    .ssb-builder-canvas { background:#f7f8fc; padding:24px; overflow-y:auto; min-width:0; }
    .ssb-canvas-header { margin-bottom:16px; }
    .ssb-canvas-header input { font-size:1.4rem; font-weight:700; border:none; background:transparent; width:100%; outline:none; color:#1f2937; border-bottom:2px dashed #e5e7eb; padding-bottom:6px; }
    .ssb-canvas-header input:focus { border-bottom-color:#667eea; }
    .ssb-canvas-header textarea { font-size:.9rem; border:none; background:transparent; width:100%; outline:none; color:#6b7280; resize:none; margin-top:4px; }

    .ssb-drop-zone { min-height:300px; border:2px dashed #e5e7eb; border-radius:10px; padding:16px; transition:all .2s; }
    .ssb-drop-zone.drag-over { border-color:#667eea; background:rgba(102,126,234,.05); }
    .ssb-drop-placeholder { text-align:center; padding:60px 20px; color:#9ca3af; }
    .ssb-drop-placeholder svg { width:48px; height:48px; margin:0 auto 12px; display:block; opacity:.4; }

    .ssb-field-block { background:#fff; border:2px solid #e5e7eb; border-radius:10px; padding:14px; margin-bottom:10px; cursor:grab; position:relative; transition:all .2s; }
    .ssb-field-block:hover, .ssb-field-block.active { border-color:#667eea; box-shadow:0 0 0 3px rgba(102,126,234,.1); }
    .ssb-field-block.ssb-ui-sortable-helper { box-shadow:0 8px 24px rgba(0,0,0,.15); opacity:.9; }
    .ssb-field-block-header { display:flex; align-items:center; gap:8px; }
    .ssb-field-drag-handle { color:#9ca3af; cursor:grab; font-size:1.1rem; padding:2px 4px; }
    .ssb-field-type-badge { background:#f3f4f6; border-radius:4px; padding:2px 8px; font-size:.7rem; font-weight:700; color:#6b7280; text-transform:uppercase; letter-spacing:.5px; }
    .ssb-field-label-preview { flex:1; font-weight:600; font-size:.9rem; color:#374151; }
    .ssb-field-required-dot { width:8px; height:8px; border-radius:50%; background:#ef4444; display:none; }
    .ssb-field-required-dot.visible { display:block; }
    .ssb-field-actions { display:flex; gap:4px; margin-left:auto; }
    .ssb-field-btn { background:none; border:none; cursor:pointer; padding:4px 6px; border-radius:4px; font-size:.85rem; color:#9ca3af; transition:all .15s; }
    .ssb-field-btn:hover { background:#f3f4f6; color:#374151; }
    .ssb-field-btn.del:hover { background:#fef2f2; color:#ef4444; }

    .ssb-field-half-row { display:grid; grid-template-columns:1fr 1fr; gap:10px; }

    /* Inspector */
    .ssb-builder-inspector { background:#fff; border-left:1px solid #e5e7eb; padding:0; overflow-y:auto; min-width:0; box-shadow:-8px 0 24px rgba(15,23,42,.035); }
    .ssb-inspector-header { padding:14px 16px; border-bottom:1px solid #e5e7eb; background:#f9fafb; }
    .ssb-inspector-header h3 { margin:0; font-size:.9rem; font-weight:700; color:#374151; }
    .ssb-inspector-body { padding:20px; }
    .ssb-inspector-field{background:#fff}.ssb-style-grid{gap:12px}.ssb-color-control{background:#f8fafc;padding:4px;border:1px solid #edf0f4;border-radius:8px}.ssb-color-control .ssb-color-hex{background:#fff}.ssb-style-color{width:44px;height:40px}.ssb-inspector-section-title{margin-top:24px;padding-top:16px}
    .ssb-inspector-empty { padding:40px 20px; text-align:center; color:#9ca3af; font-size:.875rem; }
    .ssb-inspector-field { margin-bottom:14px; }
    .ssb-inspector-label { display:block; font-size:.75rem; font-weight:700; color:#6b7280; text-transform:uppercase; letter-spacing:.5px; margin-bottom:5px; }
    .ssb-inspector-input { width:100%; box-sizing:border-box; min-width:0; padding:7px 10px; border:1.5px solid #e5e7eb; border-radius:6px; font-size:.875rem; background:#fff; }
    .ssb-inspector-input:focus { outline:none; border-color:#667eea; }
    .ssb-inspector-toggle { display:flex; align-items:center; gap:10px; }
    .ssb-inspector-toggle input[type=checkbox] { width:16px; height:16px; accent-color:#667eea; }
    .ssb-options-list { margin-top:6px; }
    .ssb-option-row { display:flex; gap:6px; margin-bottom:6px; }
    .ssb-option-row input { flex:1; padding:6px 8px; border:1.5px solid #e5e7eb; border-radius:6px; font-size:.8rem; }
    .ssb-option-del { background:none; border:none; cursor:pointer; color:#ef4444; font-size:1rem; padding:2px 6px; }
    .ssb-add-option { background:none; border:1.5px dashed #e5e7eb; border-radius:6px; padding:6px; width:100%; cursor:pointer; color:#6b7280; font-size:.8rem; transition:all .15s; }
    .ssb-add-option:hover { border-color:#667eea; color:#667eea; }

    .ssb-width-toggle { display:flex; gap:6px; }
    .ssb-width-btn { flex:1; padding:6px; border:1.5px solid #e5e7eb; border-radius:6px; text-align:center; cursor:pointer; font-size:.8rem; font-weight:600; color:#6b7280; transition:all .15s; }
    .ssb-width-btn.active { border-color:#667eea; background:#667eea; color:#fff; }

    /* Form settings tabs in inspector */
    .ssb-inspector-tabs { display:flex; border-bottom:1px solid #e5e7eb; }
    .ssb-inspector-tab { flex:1; padding:10px; text-align:center; font-size:.8rem; font-weight:600; cursor:pointer; color:#6b7280; border-bottom:2px solid transparent; transition:all .15s; }
    .ssb-inspector-tab.active { color:#667eea; border-bottom-color:#667eea; }

    /* Save bar */
    .ssb-save-bar { position:fixed; bottom:0; left:160px; right:0; background:#1f2937; padding:12px 24px; display:flex; align-items:center; justify-content:space-between; z-index:100; box-shadow:0 -4px 16px rgba(0,0,0,.15); }
    .ssb-save-bar-info { color:#9ca3af; font-size:.875rem; }
    .ssb-save-bar-info strong { color:#fff; }
    .ssb-save-btn { background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; border:none; padding:10px 28px; border-radius:8px; font-weight:700; font-size:.95rem; cursor:pointer; transition:all .2s; }
    .ssb-save-btn:hover { transform:translateY(-1px); box-shadow:0 4px 12px rgba(102,126,234,.4); }
    .ssb-save-btn:disabled { opacity:.6; cursor:not-allowed; transform:none; }

    @media (max-width: 1280px) {
        .ssb-builder { grid-template-columns:190px minmax(400px,1fr) 350px; }
    }
    @media (max-width: 1180px) {
        .ssb-builder { grid-template-columns:190px minmax(340px,1fr) 330px; }
        .ssb-style-grid { grid-template-columns:1fr; }
    }
    @media (max-width: 960px) {
        .ssb-builder { grid-template-columns:1fr; height:auto; min-height:0; overflow:visible; }
        .ssb-builder-palette { max-height:260px; }
        .ssb-builder-canvas { min-height:520px; }
        .ssb-builder-inspector { border-left:0; border-top:1px solid #e5e7eb; min-height:420px; }
        .ssb-save-bar { left:0; padding:10px 14px; }
        .ssb-save-bar-info { font-size:.75rem; }
    }

    /* Entries */
    .ssb-entries-table { width:100%; border-collapse:collapse; }
    .ssb-entries-table th { background:#f9fafb; padding:10px 14px; text-align:left; font-size:.8rem; text-transform:uppercase; letter-spacing:.5px; color:#6b7280; border-bottom:2px solid #e5e7eb; }
    .ssb-entries-table td { padding:10px 14px; border-bottom:1px solid #f3f4f6; font-size:.875rem; vertical-align:top; }
    .ssb-entries-table tr.unread td { background:#fffbeb; }
    .ssb-entry-badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:.7rem; font-weight:700; }
    .ssb-entry-badge.unread { background:#fef3c7; color:#92400e; }
    .ssb-entry-badge.read { background:#d1fae5; color:#065f46; }
    .ssb-entry-expand { cursor:pointer; color:#667eea; font-size:.8rem; text-decoration:underline; }
    .ssb-entry-detail { display:none; margin-top:8px; background:#f9fafb; border-radius:6px; padding:10px; }
    .ssb-entry-detail table { width:100%; border-collapse:collapse; }
    .ssb-entry-detail td { padding:4px 8px; border-bottom:1px solid #e5e7eb; font-size:.8rem; }
    .ssb-entry-detail td:first-child { font-weight:600; color:#667eea; width:35%; }
'; }

// ── Forms List Page ────────────────────────────────────────────────────────
function ssb_forms_list_page() {
    if ( function_exists('ssb_license_admin_guard') && ! ssb_license_admin_guard('forms') ) return;
    $action = sanitize_key( $_GET['ssb_action'] ?? '' );

    if ( $action === 'edit' || $action === 'new' ) {
        ssb_forms_builder_page();
        return;
    }
    if ( $action === 'entries' ) {
        ssb_forms_entries_page();
        return;
    }

    $forms = ssb_get_all_forms();
    global $wpdb;
    ?>
    <div class="wrap ssb-fb-wrap">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
            <h1 style="margin:0;">📝 Form Builder</h1>
            <a href="<?php echo admin_url('admin.php?page=ssb-forms&ssb_action=new'); ?>" class="button button-primary button-large">+ Create New Form</a>
        </div>
        <p style="color:#6b7280;margin-top:4px;">Create custom forms and embed them anywhere with a shortcode.</p>

        <?php if ( empty($forms) ): ?>
            <div style="text-align:center;padding:80px 20px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;margin-top:20px;">
                <div style="font-size:3rem;margin-bottom:16px;">📋</div>
                <h2 style="color:#374151;">No forms yet</h2>
                <p style="color:#6b7280;">Create your first form to get started.</p>
                <a href="<?php echo admin_url('admin.php?page=ssb-forms&ssb_action=new'); ?>" class="button button-primary button-large">Create Your First Form</a>
            </div>
        <?php else: ?>
            <div class="ssb-form-cards">
                <?php
                    // Ensure entries table exists before counting
                    $entries_tbl = $wpdb->prefix . 'ssb_form_entries';
                    $entries_tbl_exists = (bool) $wpdb->get_var( "SHOW TABLES LIKE '$entries_tbl'" );
                    foreach ( $forms as $form ):
                    $entry_count = $entries_tbl_exists ? (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}ssb_form_entries WHERE form_id = %d", $form->id
                    )) : 0;
                    $unread = $entries_tbl_exists ? (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}ssb_form_entries WHERE form_id = %d AND status='unread'", $form->id
                    )) : 0;
                    $field_count = count($form->fields);
                    $shortcode = '[ssb_form id="' . $form->id . '"]';
                ?>
                <div class="ssb-form-card">
                    <div style="display:flex;align-items:start;justify-content:space-between;margin-bottom:6px;">
                        <h3 class="ssb-form-card-title"><?php echo esc_html($form->form_name); ?></h3>
                        <span style="background:<?php echo $form->status==='active' ? '#d1fae5' : '#fee2e2'; ?>;color:<?php echo $form->status==='active' ? '#065f46' : '#991b1b'; ?>;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700;"><?php echo ucfirst($form->status); ?></span>
                    </div>
                    <?php if ( $form->description ): ?>
                        <p style="font-size:.8rem;color:#6b7280;margin:0 0 8px;"><?php echo esc_html($form->description); ?></p>
                    <?php endif; ?>
                    <div class="ssb-form-card-meta">
                        <?php echo $field_count; ?> field<?php echo $field_count !== 1 ? 's' : ''; ?> &nbsp;·&nbsp;
                        <?php echo $entry_count; ?> submission<?php echo $entry_count !== 1 ? 's' : ''; ?>
                        <?php if ($unread): ?><span style="background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:8px;font-size:.7rem;font-weight:700;"><?php echo $unread; ?> new</span><?php endif; ?>
                    </div>
                    <div class="ssb-form-card-sc" title="Click to copy shortcode" onclick="navigator.clipboard.writeText(this.textContent);this.style.background='#d1fae5';setTimeout(()=>this.style.background='',1000);">
                        <?php echo esc_html($shortcode); ?>
                    </div>
                    <div class="ssb-form-card-actions">
                        <a href="<?php echo admin_url('admin.php?page=ssb-forms&ssb_action=edit&form_id=' . $form->id); ?>" class="button button-small">✏️ Edit</a>
                        <a href="<?php echo admin_url('admin.php?page=ssb-forms&ssb_action=entries&form_id=' . $form->id); ?>" class="button button-small">📥 Entries (<?php echo $entry_count; ?>)</a>
                        <button class="button button-small ssb-delete-form" data-id="<?php echo $form->id; ?>" data-name="<?php echo esc_attr($form->form_name); ?>" style="color:#dc2626;">🗑 Delete</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
    jQuery(document).ready(function($){
        $('.ssb-delete-form').on('click', function(){
            var name = $(this).data('name');
            var id   = $(this).data('id');
            if (!confirm('Delete form "' + name + '" and ALL its submissions? This cannot be undone.')) return;
            $.post(ssbForms.ajaxUrl, { action:'ssb_delete_form', nonce:ssbForms.nonce, form_id:id }, function(r){
                if (r.success) location.reload();
                else alert(r.data.msg || 'Error');
            });
        });
    });
    </script>
    <?php
}

// ── Form Builder Page ──────────────────────────────────────────────────────
function ssb_forms_builder_page() {
    if ( function_exists('ssb_license_admin_guard') && ! ssb_license_admin_guard('builder') ) return;
    $form_id = intval( $_GET['form_id'] ?? 0 );
    $form    = $form_id ? ssb_get_form( $form_id ) : null;

    $form_name   = $form ? $form->form_name   : '';
    $description = $form ? $form->description : '';
    $fields_json = $form ? wp_json_encode( $form->fields )   : '[]';
    $settings    = $form ? $form->settings : [];
    $settings_json = wp_json_encode( $settings );
    ?>
    <div class="wrap ssb-fb-wrap" style="margin-right:0;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">
            <a href="<?php echo admin_url('admin.php?page=ssb-forms'); ?>" style="color:#6b7280;text-decoration:none;font-size:.9rem;">← All Forms</a>
            <h1 style="margin:0;"><?php echo $form_id ? 'Edit Form' : 'Create New Form'; ?></h1>
            <?php if ($form_id): ?>
                <code style="background:#f3f4f6;padding:4px 10px;border-radius:6px;font-size:.85rem;">[ssb_form id="<?php echo $form_id; ?>"]</code>
            <?php endif; ?>
        </div>

        <div class="ssb-builder">

            <!-- Palette -->
            <div class="ssb-builder-palette">
                <h3>Field Types</h3>
                <?php
                $palette = [
                    ['text',      '📝', 'Text'],
                    ['email',     '📧', 'Email'],
                    ['phone',     '📞', 'Phone'],
                    ['number',    '🔢', 'Number'],
                    ['textarea',  '📄', 'Textarea'],
                    ['select',    '📋', 'Dropdown'],
                    ['radio',     '⚪', 'Radio'],
                    ['checkbox',  '☑️',  'Checkbox'],
                    ['date',      '📅', 'Date'],
                    ['timeslot',  '🕐', 'Time Slots'],
                    ['time',      '⏰', 'Time'],
                    ['timezone',  '🌍', 'Timezone'],
                    ['url',       '🔗', 'URL'],
                    ['heading',   '🔤', 'Heading'],
                    ['divider',   '➖', 'Divider'],
                ];
                foreach ($palette as [$type, $icon, $label]): ?>
                    <div class="ssb-palette-item" data-type="<?php echo $type; ?>">
                        <span class="pi"><?php echo $icon; ?></span>
                        <span><?php echo $label; ?></span>
                    </div>
                <?php endforeach; ?>

                <h3 style="margin-top:24px;">Templates</h3>
                <div class="ssb-palette-item" data-template="contact" style="background:#1d4ed8;border-color:#2563eb;">
                    <span class="pi">✉️</span><span>Contact Form</span>
                </div>
                <div class="ssb-palette-item" data-template="lead" style="background:#065f46;border-color:#059669;">
                    <span class="pi">🎯</span><span>Lead Capture</span>
                </div>
                <div class="ssb-palette-item" data-template="survey" style="background:#7c3aed;border-color:#8b5cf6;">
                    <span class="pi">📊</span><span>Survey</span>
                </div>
            </div>

            <!-- Canvas -->
            <div class="ssb-builder-canvas">
                <div class="ssb-canvas-header">
                    <label style="display:block;font-size:.72rem;font-weight:700;color:#6b7280;margin-bottom:4px;">Internal Form Name (not shown on website)</label>
                    <input type="text" id="ssb-form-name" placeholder="e.g. Consultation Booking" value="<?php echo esc_attr($form_name); ?>">
                    <textarea id="ssb-form-desc" rows="1" placeholder="Optional description…" style="width:100%;font-family:inherit;"><?php echo esc_textarea($description); ?></textarea>
                </div>

                <ul id="ssb-drop-zone" class="ssb-drop-zone">
                    <li class="ssb-drop-placeholder" id="ssb-empty-hint">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v16m8-8H4"/></svg>
                        Click a field type on the left to add it here,<br>or choose a template to start quickly.
                    </li>
                </ul>

                <!-- Preview pane -->
                <div style="margin-top:24px;padding:20px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                        <h3 style="margin:0;font-size:.9rem;color:#6b7280;text-transform:uppercase;letter-spacing:1px;">Live Preview</h3>
                    </div>
                    <div id="ssb-live-preview" style="pointer-events:none;"></div>
                </div>
            </div>

            <!-- Inspector -->
            <div class="ssb-builder-inspector">
                <div class="ssb-inspector-tabs">
                    <div class="ssb-inspector-tab active" data-tab="field">Field</div>
                    <div class="ssb-inspector-tab" data-tab="form">Form Settings</div>
                </div>

                <!-- Field inspector -->
                <div id="ssb-inspector-field" class="ssb-inspector-body">
                    <div class="ssb-inspector-empty">
                        <div style="font-size:2rem;margin-bottom:8px;">👈</div>
                        Click a field to edit its properties
                    </div>
                </div>

                <!-- Form settings inspector -->
                <div id="ssb-inspector-form" class="ssb-inspector-body" style="display:none;">
                    <div class="ssb-inspector-section-title">Display & Identity</div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Display Title</label>
                        <input class="ssb-inspector-input" id="set-display-title" value="<?php echo esc_attr($settings['display_title'] ?? $form_name); ?>" placeholder="Title shown to visitors">
                        <p style="font-size:.75rem;color:#9ca3af;margin-top:4px;">Separate from the internal Form Name. Leave blank to use the Form Name.</p>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="set-show-title" <?php checked(array_key_exists('show_title',$settings) ? !empty($settings['show_title']) : true); ?>> <span>Show form title on the website</span></label>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="set-show-labels" <?php checked(array_key_exists('show_labels',$settings) ? !empty($settings['show_labels']) : true); ?>> <span>Show field labels on the website</span></label>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="set-show-description" <?php checked(array_key_exists('show_description',$settings) ? !empty($settings['show_description']) : true); ?>> <span>Show form description on the website</span></label>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Submit Button Label</label>
                        <input class="ssb-inspector-input" id="set-submit-label" value="<?php echo esc_attr($settings['submit_label'] ?? 'Submit'); ?>">
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Success Message</label>
                        <textarea class="ssb-inspector-input" id="set-success-msg" rows="3"><?php echo esc_textarea($settings['success_msg'] ?? 'Thank you! Your message has been sent.'); ?></textarea>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Notification Email</label>
                        <input class="ssb-inspector-input" type="text" id="set-notify-email" value="<?php echo esc_attr($settings['notify_email'] ?? get_option('admin_email')); ?>">
                        <p style="font-size:.75rem;color:#9ca3af;margin-top:4px;">Where to send submission alerts. Separate multiple emails with commas.</p>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Email Subject / Title</label>
                        <input class="ssb-inspector-input" id="set-email-subject" value="<?php echo esc_attr($settings['email_subject'] ?? ''); ?>" placeholder="Leave blank to use form name">
                        <p style="font-size:.75rem;color:#9ca3af;margin-top:4px;">Custom subject sent with notification email. If blank, the form title is used.</p>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle">
                            <input type="checkbox" id="set-send-copy" <?php checked(!empty($settings['send_copy'])); ?>>
                            <span style="font-size:.85rem;">Send copy to submitter's email</span>
                        </label>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Redirect URL after submit</label>
                        <input class="ssb-inspector-input" type="url" id="set-redirect-url" value="<?php echo esc_attr($settings['redirect_url'] ?? ''); ?>" placeholder="https://... (leave blank for success msg)">
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-label">Form Primary Color (override)</label>
                        <div class="ssb-color-control"><input class="ssb-inspector-input ssb-color-hex" type="text" id="set-primary-color" value="<?php echo esc_attr($settings['primary_color'] ?? get_option('ssb_primary_color','#667eea')); ?>" maxlength="7" placeholder="#667eea"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="set-primary-color" value="<?php echo esc_attr($settings['primary_color'] ?? get_option('ssb_primary_color','#667eea')); ?>"></div>
                    </div>                    <div class="ssb-inspector-section-title">Integrations</div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="set-stripe-enabled"> <span>Enable Stripe for this form</span></label>
                        <div id="ssb-stripe-settings" class="ssb-integration-panel">
                            <label class="ssb-inspector-label">Amount</label>
                            <input class="ssb-inspector-input" type="number" min="0" step="0.01" id="set-stripe-amount" value="0">
                            <label class="ssb-inspector-label">Currency</label>
                            <input class="ssb-inspector-input" id="set-stripe-currency" value="USD" maxlength="3">
                            <label class="ssb-inspector-label">Payment description</label>
                            <input class="ssb-inspector-input" id="set-stripe-description" value="" placeholder="Form payment">
                            <p class="ssb-inspector-note">Uses the Stripe API keys configured in the plugin. Set the amount to 0 to collect no payment.</p><p class="ssb-inspector-note ssb-payment-link-note"><a href="<?php echo esc_url(admin_url('admin.php?page=ssb-payment-buttons')); ?>">Create a Stripe Payment Button shortcode →</a></p>
                        </div>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="set-calendar-enabled"> <span>Enable Google Calendar for this form</span></label>
                        <div id="ssb-calendar-settings" class="ssb-integration-panel">
                            <label class="ssb-inspector-label">Calendar ID</label>
                            <input class="ssb-inspector-input" id="set-calendar-id" value="primary" placeholder="primary">
                            <label class="ssb-inspector-label">Event label</label>
                            <input class="ssb-inspector-input" id="set-calendar-label" value="" placeholder="Leave blank for global event label">
                            <label class="ssb-inspector-label">Brand name</label>
                            <input class="ssb-inspector-input" id="set-calendar-brand" value="" placeholder="Leave blank for website name">
                        </div>
                    </div>

                    <div class="ssb-inspector-section-title">Form Appearance</div>
                    <div class="ssb-style-grid">
                        <div><label class="ssb-inspector-label">Form background</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-form-bg" value="#ffffff" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-form-bg" value="#ffffff"></div><label class="ssb-inspector-toggle" style="margin-top:7px;"><input type="checkbox" id="style-form-bg-transparent"><span style="font-size:.8rem;">Transparent background</span></label></div>
                        <div><label class="ssb-inspector-label">Form border</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-form-border" value="#edf0f3" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-form-border" value="#edf0f3"></div><label class="ssb-inspector-toggle" style="margin-top:7px;"><input type="checkbox" id="style-form-border-enabled" checked><span style="font-size:.8rem;">Show form border</span></label></div>
                        <div><label class="ssb-inspector-label">Form radius</label><input class="ssb-inspector-input" type="number" id="style-form-radius" min="0" max="60"></div>
                        <div><label class="ssb-inspector-label">Form padding</label><input class="ssb-inspector-input" type="number" id="style-form-padding" min="0" max="100"></div>
                        <div><label class="ssb-inspector-label">Field gap</label><input class="ssb-inspector-input" type="number" id="style-field-gap" min="0" max="60"></div>
                        <div><label class="ssb-inspector-label">Label color</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-label-color" value="#6b7280" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-label-color" value="#6b7280"></div></div>
                        <div><label class="ssb-inspector-label">Label size</label><input class="ssb-inspector-input" type="number" id="style-label-size" min="9" max="24"></div>
                        <div><label class="ssb-inspector-label">Input background</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-bg" value="#f9fafb" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-bg" value="#f9fafb"></div></div>
                        <div><label class="ssb-inspector-label">Input text</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-text" value="#111827" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-text" value="#111827"></div></div>
                        <div><label class="ssb-inspector-label">Input border</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-border" value="#e5e7eb" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-border" value="#e5e7eb"></div></div>
                        <div><label class="ssb-inspector-label">Focus border</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-focus-border" value="#667eea" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-focus-border" value="#667eea"></div></div>
                        <div><label class="ssb-inspector-label">Focus ring</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-focus-ring" value="#dbeafe" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-focus-ring" value="#dbeafe"></div></div>
                        <div><label class="ssb-inspector-label">Error border</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-error-border" value="#dc2626" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-error-border" value="#dc2626"></div></div>
                        <div><label class="ssb-inspector-label">Error background</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-error-bg" value="#fef2f2" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-error-bg" value="#fef2f2"></div></div>
                        <div><label class="ssb-inspector-label">Placeholder color</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-input-placeholder" value="#94a3b8" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-input-placeholder" value="#94a3b8"></div></div>
                        <div><label class="ssb-inspector-label">Input border width</label><input class="ssb-inspector-input" type="number" id="style-input-border-width" min="0" max="6"></div>
                        <div><label class="ssb-inspector-label">Input radius</label><input class="ssb-inspector-input" type="number" id="style-input-radius" min="0" max="60"></div>
                        <div><label class="ssb-inspector-label">Input padding</label><input class="ssb-inspector-input" type="number" id="style-input-padding" min="4" max="40"></div>
                        <div><label class="ssb-inspector-label">Input font size</label><input class="ssb-inspector-input" type="number" id="style-input-font-size" min="10" max="30"></div>
                    </div>

                    <div class="ssb-inspector-section-title">Submit Button</div>
                    <div class="ssb-style-grid">
                        <div><label class="ssb-inspector-label">Background</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-button-bg" value="#667eea" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-button-bg" value="#667eea"></div></div>
                        <div><label class="ssb-inspector-label">Text color</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-button-text" value="#ffffff" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-button-text" value="#ffffff"></div></div>
                        <div><label class="ssb-inspector-label">Hover background</label><div class="ssb-color-control"><input type="text" class="ssb-color-hex ssb-inspector-input" id="style-button-hover-bg" value="#4f46e5" maxlength="7" placeholder="#000000"><input type="color" class="ssb-style-color ssb-color-picker" data-color-for="style-button-hover-bg" value="#4f46e5"></div></div>
                        <div><label class="ssb-inspector-label">Radius</label><input class="ssb-inspector-input" type="number" id="style-button-radius" min="0" max="60"></div>
                        <div><label class="ssb-inspector-label">Vertical padding</label><input class="ssb-inspector-input" type="number" id="style-button-padding-y" min="4" max="40"></div>
                        <div><label class="ssb-inspector-label">Horizontal padding</label><input class="ssb-inspector-input" type="number" id="style-button-padding-x" min="4" max="80"></div>
                        <div><label class="ssb-inspector-label">Font size</label><input class="ssb-inspector-input" type="number" id="style-button-font-size" min="10" max="30"></div>
                    </div>
                    <div class="ssb-inspector-field">
                        <label class="ssb-inspector-toggle"><input type="checkbox" id="style-button-full-width"> <span>Make submit button full width</span></label>
                    </div>

                </div>
            </div>
        </div>

        <!-- Save bar -->
        <div class="ssb-save-bar">
            <div class="ssb-save-bar-info">
                <strong id="ssb-field-count">0</strong> fields &nbsp;·&nbsp;
                <?php if ($form_id): ?>Shortcode: <strong>[ssb_form id="<?php echo $form_id; ?>"]</strong><?php else: ?>Shortcode generated after save<?php endif; ?>
            </div>
            <div style="display:flex;gap:12px;align-items:center;">
                <span id="ssb-save-status" style="color:#9ca3af;font-size:.85rem;"></span>
                <button class="ssb-save-btn" id="ssb-save-form">💾 Save Form</button>
            </div>
        </div>
    </div>

    <!-- Hidden inputs -->
    <input type="hidden" id="ssb-form-id" value="<?php echo $form_id; ?>">
    <input type="hidden" id="ssb-fields-data" value="">
    <input type="hidden" id="ssb-settings-data" value="">
    <script>
        window.ssbInitialFields   = <?php echo $fields_json; ?>;
        window.ssbInitialSettings = <?php echo $settings_json; ?>;
    </script>
    <?php
}

// ── Form Entries Page ──────────────────────────────────────────────────────
function ssb_forms_entries_page() {
    if ( function_exists('ssb_license_admin_guard') && ! ssb_license_admin_guard('forms') ) return;
    $form_id = intval( $_GET['form_id'] ?? 0 );
    $form    = ssb_get_form( $form_id );
    if ( ! $form ) { echo '<div class="wrap"><p>Form not found.</p></div>'; return; }

    $entries = ssb_get_form_entries( $form_id );
    global $wpdb;
    $total  = count($entries);
    $unread = array_filter($entries, fn($e) => $e->status === 'unread');
    ?>
    <div class="wrap ssb-fb-wrap">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
            <a href="<?php echo admin_url('admin.php?page=ssb-forms'); ?>" style="color:#6b7280;text-decoration:none;font-size:.9rem;">← All Forms</a>
            <h1 style="margin:0;">📥 Entries — <?php echo esc_html($form->form_name); ?></h1>
        </div>

        <div style="display:flex;gap:16px;margin-bottom:20px;">
            <?php foreach ([['Total',$total,'#667eea'],['Unread',count($unread),'#f59e0b'],['Read',$total-count($unread),'#10b981']] as [$lbl,$cnt,$clr]): ?>
                <div style="background:#fff;border:2px solid <?php echo $clr; ?>;border-radius:10px;padding:12px 20px;text-align:center;min-width:100px;">
                    <div style="font-size:1.8rem;font-weight:800;color:<?php echo $clr; ?>;"><?php echo $cnt; ?></div>
                    <div style="font-size:.8rem;color:#6b7280;font-weight:600;"><?php echo $lbl; ?></div>
                </div>
            <?php endforeach; ?>
            <div style="margin-left:auto;align-self:center;">
                <a href="<?php echo admin_url('admin.php?page=ssb-forms&ssb_action=edit&form_id=' . $form_id); ?>" class="button">✏️ Edit Form</a>
                <button id="ssb-export-csv" class="button" style="margin-left:6px;">⬇️ Export CSV</button>
            </div>
        </div>

        <?php if ( empty($entries) ): ?>
            <div style="text-align:center;padding:60px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;color:#6b7280;">
                <div style="font-size:2.5rem;margin-bottom:12px;">📭</div>
                No submissions yet. Share your form shortcode to start collecting responses.
            </div>
        <?php else: ?>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;">
            <table class="ssb-entries-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Summary</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($entries as $i => $entry):
                        $data    = json_decode($entry->entry_data, true) ?: [];
                        $preview = array_slice($data, 0, 2);
                        $summary = implode(' · ', array_map(fn($v) => substr($v,0,40), array_values($preview)));
                    ?>
                    <tr class="<?php echo $entry->status; ?>" data-entry-id="<?php echo $entry->id; ?>">
                        <td style="color:#9ca3af;"><?php echo $total - $i; ?></td>
                        <td>
                            <div style="font-weight:600;margin-bottom:4px;"><?php echo esc_html($summary ?: '(empty)'); ?></div>
                            <span class="ssb-entry-expand" onclick="this.closest('tr').nextElementSibling.querySelector('.ssb-entry-detail').style.display==='none'?(this.closest('tr').nextElementSibling.querySelector('.ssb-entry-detail').style.display='block',this.textContent='▲ Hide'):(this.closest('tr').nextElementSibling.querySelector('.ssb-entry-detail').style.display='none',this.textContent='▼ View all fields')">▼ View all fields</span>
                        </td>
                        <td style="white-space:nowrap;color:#6b7280;font-size:.8rem;"><?php echo date('M d, Y H:i', strtotime($entry->created_at)); ?></td>
                        <td><span class="ssb-entry-badge <?php echo $entry->status; ?>"><?php echo ucfirst($entry->status); ?></span></td>
                        <td style="white-space:nowrap;">
                            <?php if ($entry->status === 'unread'): ?>
                                <button class="button button-small ssb-mark-read" data-id="<?php echo $entry->id; ?>">✓ Read</button>
                            <?php endif; ?>
                            <button class="button button-small ssb-del-entry" data-id="<?php echo $entry->id; ?>" style="color:#dc2626;margin-left:4px;">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5" style="padding:0;">
                            <div class="ssb-entry-detail" style="display:none;padding:12px;">
                                <table>
                                    <?php foreach ($data as $label => $value): ?>
                                    <tr>
                                        <td><?php echo esc_html($label); ?></td>
                                        <td><?php echo nl2br(esc_html($value)); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <script>
    jQuery(document).ready(function($){
        var entries = <?php echo wp_json_encode( array_map(function($e){ return ['id'=>$e->id,'data'=>json_decode($e->entry_data,true),'date'=>$e->created_at]; }, $entries) ); ?>;

        $('.ssb-mark-read').on('click', function(){
            var id = $(this).data('id'), $btn = $(this);
            $.post(ssbForms.ajaxUrl, {action:'ssb_update_entry', nonce:ssbForms.nonce, entry_id:id, entry_action:'read'}, function(){
                $btn.closest('tr').removeClass('unread').find('.ssb-entry-badge').removeClass('unread').addClass('read').text('Read');
                $btn.remove();
            });
        });

        $('.ssb-del-entry').on('click', function(){
            if (!confirm('Delete this entry?')) return;
            var id = $(this).data('id'), $row = $(this).closest('tr');
            $.post(ssbForms.ajaxUrl, {action:'ssb_update_entry', nonce:ssbForms.nonce, entry_id:id, entry_action:'delete'}, function(){
                $row.next('tr').remove();
                $row.remove();
            });
        });

        // CSV export
        $('#ssb-export-csv').on('click', function(){
            if (!entries.length) { alert('No entries to export.'); return; }
            var allKeys = [];
            entries.forEach(function(e){ Object.keys(e.data||{}).forEach(function(k){ if(!allKeys.includes(k)) allKeys.push(k); }); });
            var csvRows = [['Date'].concat(allKeys).map(function(v){ return '"'+String(v).replace(/"/g,'""')+'"'; }).join(',')];
            entries.forEach(function(e){
                var row = [e.date].concat(allKeys.map(function(k){ return e.data[k]||''; }));
                csvRows.push(row.map(function(v){ return '"'+String(v).replace(/"/g,'""')+'"'; }).join(','));
            });
            var blob = new Blob([csvRows.join('\n')], {type:'text/csv'});
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = '<?php echo sanitize_file_name($form->form_name); ?>-entries.csv';
            a.click();
        });
    });
    </script>
    <?php
}
