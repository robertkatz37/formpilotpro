jQuery(document).ready(function($){

    // ── Color pickers ──────────────────────────────────────────
    $('.ssb-color-picker').wpColorPicker({
        change: function(){ setTimeout(updatePreview, 50); },
        clear:  function(){ setTimeout(updatePreview, 50); }
    });

    function updatePreview() {
        var p  = $('[name="ssb_primary_color"]').val()     || '#667eea';
        var s  = $('[name="ssb_secondary_color"]').val()   || '#764ba2';
        var bt = $('[name="ssb_button_text_color"]').val() || '#ffffff';
        var br = $('[name="ssb_border_radius"]').val()     || '12';
        $('#ssb-preview-btn').css({
            background:   'linear-gradient(135deg,' + p + ',' + s + ')',
            color:        bt,
            borderRadius: br + 'px'
        });
    }

    $('[name="ssb_border_radius"]').on('input', updatePreview);

    // ── Port quick-select buttons ──────────────────────────────
    $('.ssb-port-btn').on('click', function(){
        $('#ssb_smtp_port').val($(this).data('port'));
        $('#ssb_smtp_encryption').val($(this).data('enc'));
    });

    // ── Namecheap auto-fill ────────────────────────────────────
    $('#ssb-autofill-namecheap').on('click', function(){
        $('#ssb_smtp_host').val('mail.privateemail.com');
        $('#ssb_smtp_port').val('587');
        $('#ssb_smtp_encryption').val('tls');
        $('[name="ssb_smtp_enabled"]').prop('checked', true);
        $(this).text('Filled! Now enter your email + password below, then Save.').prop('disabled', true);
    });

    // ── Shared result display helper ──────────────────────────
    function showResult($el, type, msg) {
        var isOk   = type === 'success';
        var bg     = isOk ? '#ecfdf5' : '#fef2f2';
        var border = isOk ? '#059669' : '#dc2626';
        var color  = isOk ? '#065f46' : '#991b1b';
        $el.addClass('ssb-result-banner').css({
            display:       'block',
            background:    bg,
            borderLeft:    '3px solid ' + border,
            color:         color
        }).html(msg);
    }

    // ── SMTP test email ────────────────────────────────────────
    $('#ssb-test-smtp').on('click', function(){
        var $btn    = $(this);
        var $result = $('#ssb-test-result');
        var toAddr  = $('#ssb-test-email-addr').val().trim();

        if (!toAddr) {
            showResult($result, 'error', 'Please enter an email address to send the test to.');
            return;
        }

        $btn.prop('disabled', true).text('Sending…');
        $result.hide();

        $.post(ssbAdmin.ajaxUrl, {
            action: 'ssb_test_smtp',
            nonce:  ssbAdmin.nonce,
            to:     toAddr
        })
        .done(function(resp){
            $btn.prop('disabled', false).html('Send Test Email');
            if (resp.success) {
                showResult($result, 'success', resp.data.message);
            } else {
                var msg = (resp.data && resp.data.message) ? resp.data.message : 'Unknown error.';
                showResult($result, 'error', msg);
            }
        })
        .fail(function(xhr){
            $btn.prop('disabled', false).html('Send Test Email');
            showResult($result, 'error', 'Network error (HTTP ' + xhr.status + '). Make sure you saved settings first, then try again.');
        });
    });

    // ── Google Calendar connection test ────────────────────────
    $('#ssb-test-google').on('click', function(){
        var $btn    = $(this);
        var $result = $('#ssb-google-test-result');

        $btn.prop('disabled', true).text('Testing…');
        $result.hide();

        $.post(ssbAdmin.ajaxUrl, {
            action: 'ssb_test_google',
            nonce:  ssbAdmin.nonce
        })
        .done(function(resp){
            $btn.prop('disabled', false).html('Test Connection');
            if (resp.success) {
                showResult($result, 'success', resp.data.message);
            } else {
                var msg = (resp.data && resp.data.message) ? resp.data.message : 'Unknown error.';
                showResult($result, 'error', msg);
            }
        })
        .fail(function(xhr){
            $btn.prop('disabled', false).html('Test Connection');
            showResult($result, 'error', 'Network error (HTTP ' + xhr.status + ').');
        });
    });

});
